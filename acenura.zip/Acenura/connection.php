<?php
date_default_timezone_set('Asia/Singapore');

define('DB_HOST', 'localhost');
define('DB_USERNAME', 'acenura_acenura_new');
define('DB_PASSWORD', 'goodday123');
define('DB_NAME', 'acenura_acenura_new');
?>