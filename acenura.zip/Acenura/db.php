<?php
/**
* Author : Dinesh G ,Web Developer - Acenura

*/
include_once('connection.php');
class DB extends core
{
	private $mysqli;
	public function __construct()
	{
		$this->mysqli = new mysqli(DB_HOST, DB_USERNAME , DB_PASSWORD , DB_NAME);
		if ($this->mysqli->connect_error) 
		{
    		die('Connect Error (' . $this->mysqli->connect_errno . ') '. $this->mysqli->connect_error);
		}
	}

	private function parseArguments($args) 
	{
		$sql = $args[0];
		$numargs = count($args);
		if ($numargs > 1) 
		{
			$listarg = array();
			for ($i=1; $i<$numargs; $i++) 
			{
				$listarg[] = $args[$i];
			}
			$sql = call_user_func_array('sprintf', array_merge((array)$sql, $listarg));
		}
		return $sql;
	}  
	public function executeQuery($args) 
	{
		$numargs = count($args);
		if ($numargs == 0)
			throw new Exception("bad use of the class");
		else 
		{
			$sql = $this->parseArguments($args);
		}
		if ($sql!= "") 
		{
			//Execute the query
			$result = $this->mysqli->query($sql);
			if (!$result) throw new Exception($mysqli->error);
		}
		return $result;
	}

	public function get_result() // Get the values in database multiple values
	{  
		$args = func_get_args();
		$e="";
		$data = array();
		try
		{
			$result = $this->executeQuery($args);
		}
		catch (Exception $e)
		{
			$this->logError($args,$e);
		}
		if (!is_object($e)) 
		{		
			// parsing the data retrieved by the query
			while ($row = $result->fetch_object()) 
			{
			   $data[]=$row;
			}
			// free the memory
			$result->free_result();
		}
		return $data;
	}
	public function get_row() // Get the value in single row
	{
		$args = func_get_args();
		$e="";
		try
		{
			$result = $this->executeQuery($args);
		}
		catch (Exception $e)
		{
			$this->logError($args,$e);
		}
		if (!is_object($e)) 
		{
			$row = $result->fetch_object();
			// free the memory
			$result->free_result();
			return $row;
		}
	}

	public function rows_count() // Number of sql counts (data counts)
	{
		$args = func_get_args();
		$e="";
		try
		{
			$result = $this->executeQuery($args);
		}
		catch (Exception $e)
		{
			$this->logError($args,$e);
		}
		if (!is_object($e)) 
		{
			$row = $result->num_rows;
			// free the memory
			$result->free_result();
			return $row;
		}
	}
	public function set_query() // Create , Update ,Delete Queries
	{
		$args = func_get_args();
		$e="";
		try
		{
			$result = $this->executeQuery($args);
		}
		catch (Exception $e)
		{
			$this->logError($args,$e);
		}
		if (!is_object($e)) 
		{
			$id =$this->mysqli->insert_id;
			return $id;
		}
	}
	public function escape_string($string) // Real escape string in mysql (Special characters allow(insert)  in table)
	{
		$args = func_get_args();
		$e="";
		try
		{
			$result = $this->mysqli->real_escape_string($string);
		}
		catch (Exception $e)
		{
			$result =$this->mysqli->logError($args,$e);
		}
		return $result;
	}

}
?>