<?php

Class controllers extends core
{
	
	public function login($site)
	{
		foreach($site as $key=>$value)
		{
			$$key = $value;
		}
		include_once('views/'.$page.'.php');
	}
	public function login_ajax($site)
	{
		foreach($site as $key=>$value)
		{
			$$key = $value;
		}
		
		include_once('views/'.$page.'.php');
		
	}
	
	public function home($site)
	{
		foreach($site as $key=>$value)
		{
			$$key = $value;
		}
		
		include_once('views/header.php');
		include_once('views/'.$page.'.php');
		include_once('views/footer.php');
	}
	public function getintouch($site)
	{
		foreach($site as $key=>$value)
		{
			$$key = $value;
		}
		
		include_once('views/header.php');
		include_once('views/'.$page.'.php');
		include_once('views/footer.php');
	}
	public function detailed_requirement($site)
	{
		foreach($site as $key=>$value)
		{
			$$key = $value;
		}
		
		include_once('views/header.php');
		include_once('views/'.$page.'.php');
		include_once('views/footer.php');
	}
	public function ourworks($site)
	{
		foreach($site as $key=>$value)
		{
			$$key = $value;
		}
		
		include_once('views/header.php');
		include_once('views/'.$page.'.php');
		include_once('views/footer.php');
	}
	public function add_ourworks($site)
	{
		foreach($site as $key=>$value)
		{
			$$key = $value;
		}
		
		include_once('views/header.php');
		include_once('views/'.$page.'.php');
		include_once('views/footer.php');
	}
	public function ourworks_ajax($site)
	{
		foreach($site as $key=>$value)
		{
			$$key = $value;
		}
		
		include_once('views/'.$page.'.php');
		
	}
	
}
?>