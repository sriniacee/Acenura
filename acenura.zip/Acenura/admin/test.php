<?php
echo date('d-m-Y',strtotime('14:30'));


?>