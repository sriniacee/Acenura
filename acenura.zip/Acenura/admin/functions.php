<?php





class functions extends db

{

	
	public function passwordgenerate($length) // Password Generation 
	{
		$chars = "0123456789!@#$%&*?ABCDEFGHIJKLMNOPQRSTUVWXYZ";
		$generatepwd = "";
		for ($i = 1; $i <=$length; $i++) 
		{
			$generatepwd.= $chars[mt_rand(0, strlen($chars)-1)];
		}
		return $generatepwd;
	}
	public function codecount($title,$designation,$table)

	{

		 $mycode=$title.$designation;

		

			$getEmp=$this->get_row("SELECT * FROM  $table WHERE empNo LIKE '%$mycode%' ORDER BY id DESC LIMIT 1");

			if(!empty($getEmp))

			{

				

				$getEmpcode=str_replace($mycode,'',$getEmp->empNo);

				$getcode=sprintf("%03d", $getEmpcode+1);

				return  $mycode.$getcode;

			}

			else

			{

				

				return $mycode.'001';

			}

			

	}

	public function encrypt_text($string)

	{

		$key = 'Acee@12#$';

		

		$iv = mcrypt_create_iv(

		mcrypt_get_iv_size(MCRYPT_RIJNDAEL_128, MCRYPT_MODE_CBC),

		MCRYPT_DEV_URANDOM

		);		

		$encrypted = base64_encode(

			$iv .

			mcrypt_encrypt

			(

				MCRYPT_RIJNDAEL_128,

				hash('sha256', $key, true),

				$string,

				MCRYPT_MODE_CBC,

				$iv

			)

		);

		

		return  $encrypted;

	}

	public function decrypt_text($encrypted)

	{

		$key = 'Acee@12#$';

		

		$data = base64_decode($encrypted);

		$iv = substr($data, 0, mcrypt_get_iv_size(MCRYPT_RIJNDAEL_128, MCRYPT_MODE_CBC));

		

		$decrypted = rtrim(

		    mcrypt_decrypt(

		        MCRYPT_RIJNDAEL_128,

		        hash('sha256', $key, true),

		        substr($data, mcrypt_get_iv_size(MCRYPT_RIJNDAEL_128, MCRYPT_MODE_CBC)),

		        MCRYPT_MODE_CBC,

		        $iv

		    ),

		    "\0"

		);

		return $decrypted;

		

	}

	public function base64_to_jpeg($base64_string, $output_file) 

	{

		$ifp = fopen($output_file, "wb"); 



		$data = explode(',', $base64_string);



		fwrite($ifp, base64_decode($base64_string)); 

		fclose($ifp); 



		return $output_file; 

	}

	public function sentmail($to,$cc,$toname,$message,$subject,$file=0) // Mail Send Function

	{

		require_once('mail/class.phpmailer.php');

		

		$host="smtp.gmail.com"; 

		$domain='gmail.com';

		$password='Acenura@123';

		$company=$subject;

		

		$mail             = new PHPMailer();

		

		//$body             = preg_replace("[\]",'',$body);

		$mail->IsSMTP(); 

		$mail->SMTPDebug  = 1;            // 1 = errors and messages ,2 = messages only

		$mail->SMTPAuth   = true;                 

		$mail->SMTPSecure = "ssl";                 

		$mail->Host       = $host;

		$mail->Port       = 465;                  

		$mail->Username   = "acenurademo@".$domain;   

		$mail->Password   = $password;            

		$mail->SetFrom("acenurademo@{$domain}",$company);

		$mail->AddReplyTo("acenurademo@{$domain}",$company);

		$mail->Subject    = $subject;

		$mail->AltBody    = "To view the message, please use an HTML compatible email viewer!";

		$mail->MsgHTML($message);

		$address = $to;

		foreach($cc as $ccname=>$ccmail)

		{

			$mail->AddAddress($ccmail, $ccname);

		}

		

		if($file!=0)

		{

			foreach($file as $filename=>$filet)

			{

				$mail->AddAttachment($filet, $filename);

			}

		}

		if(!$mail->Send()) { return "Mailer Error: " . $mail->ErrorInfo;} else {

		

		  return "success";

		}

		

	}	

	public function qrcode($data, $width, $height,$savePath) 

	{

		



		$size = $width.'x'.$height;



		$QR = imagecreatefrompng('https://chart.googleapis.com/chart?cht=qr&chld=H|1&chs='.$size.'&chl='.urlencode($data));



		$logo = imagecreatefromstring(file_get_contents($logo));

		$QR_width = imagesx($QR);

		$QR_height = imagesy($QR);



		$logo_width = imagesx($logo);

		$logo_height = imagesy($logo);



		// Scale logo to fit in the QR Code

		$logo_qr_width = $QR_width/3;

		$scale = $logo_width/$logo_qr_width;

		$logo_qr_height = $logo_height/$scale;



		imagecopyresampled($QR, $logo, $QR_width/3, $QR_height/3, 0, 0,  $logo_width, $logo_height);



		header('Content-type: image/png');

		

		imagepng($QR, $savePath);

		imagedestroy($QR);

		return $QR;



	}    

	public function find_ip()

	{

		$ip;

		if (getenv("HTTP_CLIENT_IP"))

		$ip = getenv("HTTP_CLIENT_IP");

		else if(getenv("HTTP_X_FORWARDED_FOR"))

		$ip = getenv("HTTP_X_FORWARDED_FOR");

		else if(getenv("REMOTE_ADDR"))

		$ip = getenv("REMOTE_ADDR");

		else

		$ip = "UNKNOWN";

		return $ip;

	}

	public function fetchFirebaseTokenUsers($message,$table)  //push notification 

	{   

	   $query = $this->get_result("SELECT token FROM  $table WHERE isdeleted=0");

	   $fcmRegIds = array();

	   

	   foreach($query as $selquery)

	   {

		  array_push($fcmRegIds, $selquery->token);

	   }	   

	   if(isset($fcmRegIds)) 

	   {	  

			 $pushStatus = $this->pushnotification($fcmRegIds, $message);		

	   }

	}

	

    public function pushnotification($message,$title)  	// Push Message Send Both IOS and Android

	{    

		define('GOOGLE_API_KEY', 'AAAAyBLMeyo:APA91bHLsKeM3EeJLb1i-cQaUUiQG4UXhvpYztzY_g48nehVKTfIGLJPmW3TPB2Fp5YFmnpGo2kdjTvJgcF7-orzWVft1iRRKIfA0Y5gKeK1nXHCBceB48TOpzID-7eoNNO8_GSLYCk-');

		// $url = 'https://android.googleapis.com/gcm/send';

	

		$url = 'https://fcm.googleapis.com/fcm/send';



		$fields=array();

		$fields['data']['data']=array(

		'message' => $message,

		'title' => $title,

		);

		$fields['to']="/topics/shoppadalaace";



		

		$headers = array(

		'Authorization: key=' .GOOGLE_API_KEY,

		'Content-Type: application/json'

		);

		// Open connection

		$ch = curl_init();



		// Set the url, number of POST vars, POST data

		curl_setopt($ch, CURLOPT_URL, $url);

		curl_setopt($ch, CURLOPT_POST, true);

		curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);



		// Disabling SSL Certificate support temporarly

		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);



		curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));



		// Execute post

		$result = curl_exec($ch);

		if ($result === FALSE) 

		{

		die('Curl failed: ' . curl_error($ch));

		}

			// Close connection

		curl_close($ch);

		//echo $result;

   }

   

	public function ios_push($gcmid,$title,$message)

	{

		

		// Put your device token here (without spaces):

		$deviceToken = $gcmid;

		//$deviceToken = '14C61F14050A184FEF00E796154707CBCD7BC492B8C9FD1D3F0D3E7E340CF1C9';

		// Put your private key's passphrase here:

		$passphrase = 'shopshop';

		

		$ctx = stream_context_create();

		// stream_context_set_option($ctx, 'ssl', 'local_cert', 'iospush/temple_push_development.pem');

		stream_context_set_option($ctx, 'ssl', 'local_cert', 'views/app/iospem/pushcert.pem');

		stream_context_set_option($ctx, 'ssl', 'passphrase', $passphrase);



		// Open a connection to the APNS server

		//$fp = stream_socket_client('ssl://gateway.sandbox.push.apple.com:2195', $err,$errstr, 60, STREAM_CLIENT_CONNECT|STREAM_CLIENT_PERSISTENT, $ctx);

		//$fp = stream_socket_client('ssl://gateway.sandbox.push.apple.com:2195', $err,$errstr, 60, STREAM_CLIENT_CONNECT|STREAM_CLIENT_PERSISTENT, $ctx);

		$fp = stream_socket_client('ssl://gateway.sandbox.push.apple.com:2195', $err,$errstr, 60, STREAM_CLIENT_CONNECT|STREAM_CLIENT_PERSISTENT, $ctx);



		if (!$fp)

		exit("Failed to connect: $err $errstr" . PHP_EOL);



		//echo 'Connected to APNS' . PHP_EOL;

		

		$body['aps'] = array(

		'alert' =>  $message['message'],

		'sound' => "2.wav", // 0.caf, 1.wav, 2.wav

		'badge' => 0,

		'extra'=>$message['title'],

	

		);

				

		// Encode the payload as JSON

		$payload = json_encode($body);

		//echo $payload;



		if(is_array($deviceToken))

		{

			//echo 1;

			foreach($deviceToken as $dt)

			{

				// Build the binary notification

				$msg = chr(0) . pack('n', 32) . pack('H*', $dt) . pack('n', strlen($payload)) . $payload;

				

				// Send it to the server

				$result = fwrite($fp, $msg, strlen($msg));

			}

		}

		else

		{

			//echo 2;

			// Build the binary notification

			$msg = chr(0) . pack('n', 32) . pack('H*', $deviceToken) . pack('n', strlen($payload)) . $payload;

			

			// Send it to the server

			 $result = fwrite($fp, $msg, strlen($msg));

		}



		/*if (!$result)

			echo 'Message not delivered' . PHP_EOL;

		else

			echo 'Message successfully delivered' . PHP_EOL; */



		// Close the connection to the server



		fclose($fp);



		ini_set('error_reporting', E_ALL);

	}



}

?>