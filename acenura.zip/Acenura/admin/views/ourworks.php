<div class="page-bar">
<ul class="page-breadcrumb">
    <li>
        <a href="?page=home">Home</a>
        <i class="fa fa-circle"></i>
    </li>
    <li>
       <span>Our Works</span>
    </li>
    
</ul>

</div>
<div class="row">
<div class="col-md-12">
    <!-- BEGIN EXAMPLE TABLE PORTLET-->
    <div class="portlet light bordered">
        <div class="portlet-title">
            <div class="caption">
                <i class="icon-settings font-red"></i>
                <span class="caption-subject font-red sbold uppercase">Our Product</span>
            </div>
        </div>
        <div class="portlet-body">
            <div class="table-toolbar">
                <div class="row">
                    <div class="col-md-6">
                        <div class="btn-group">
                          <a href="?page=add_ourworks"> <button  class="btn green"> Add New
                                <i class="fa fa-plus"></i>
                            </button> </a>
                        </div>
                    </div>
                </div>
            </div>
            <table class="table table-striped table-bordered table-hover table-checkable order-column " id="sample_1">
                <thead>
                    <tr>
                        <th> Sl </th>
                        <th> Project Name </th>
                        <th> Platform</th>
                        <th> Site_url</th>
                        <th> Play Store_url</th>
                        <th> Ios_url </th>
                        <th> Image</th>
                        <th> About_Project</th>
                        <th> Role</th>
                        <th> Deliverable</th>
                        <th> Testimonials</th>
                        <th> Edit</th>
                        <th> Delete </th>
                    </tr>
                </thead>
                <tbody>
               <?php
                    $i=1;
                    $getproduct=$functions->get_result("SELECT * FROM `ourworks` WHERE `visible`=1 AND `is_deleted`=0 ORDER BY id DESC");
                    foreach($getproduct as $proall)
                     {   
                         $id=$proall->id;     
                                             
                     ?>
                    <tr>
                        <td> <?php echo $i; ?> </td>
                        <td> <?php echo $proall->project_name; ?> </td>
                        <td> <?php echo $proall->platform; ?> </td>
                        <td> <?php echo $proall->site_url; ?> </td>
                        <td> <?php echo $proall->playstore_url; ?> </td>
                        <td> <?php echo $proall->ios_url; ?> </td>
                        <td> <img src="<?php echo 'views/ourworks/'.$proall->image; ?>" width="100" height="100"></td>
                        <td> <?php echo substr($proall->about_project, 0 ,100); ?>... </td>
                        <td> <?php echo substr($proall->role, 0 ,100); ?>...   </td>
                        <td> <?php echo $proall->deliverables; ?>   </td>
                        <td> <?php echo substr($proall->testimonials, 0 ,100); ?>... </td>
                        <td>
                            <a href="?page=add_ourworks&id=<?php echo $id; ?>" class="btn dark btn-sm btn-outline sbold uppercase"><i class="fa fa-pencil" aria-hidden="true"> EDIT </i> </a>
                        </td>
                        <td>
                            <a onclick="deleterow('<?php echo $id; ?>','ourworks_ajax')" class="btn dark btn-sm btn-outline sbold uppercase"><i class="fa fa-pencil" aria-hidden="true"> Delete </i> </a>
                        </td>
                    </tr>
                     <?php $i++; } ?>
                </tbody>
            </table>
        </div>
    </div>
    <!-- END EXAMPLE TABLE PORTLET-->
</div>
</div>


