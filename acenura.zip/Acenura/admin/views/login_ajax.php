<?php
$controllers->start();
$type=$_REQUEST['type'];

if($type=='login')
{
	$username=$_REQUEST['username'];
	$pwd=$_REQUEST['password'];
	$checkDetail=$functions->rows_count("SELECT * FROM admin WHERE username='".$username."' && password=md5('".$pwd."')");
    if($checkDetail=='1')
	{
		$_SESSION['username']=$username;
		$_SESSION['password']=$pwd;
		echo "success";
		
	}
	else
	{
		echo "failure";
	}
}
elseif($type=='logout')
{
	session_destroy();
	echo "success";

}


?>