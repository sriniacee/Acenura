<?php
 	if(isset($_REQUEST['id']))
 	{
 		$addourworks=$functions->get_row("SELECT * FROM ourworks WHERE id='".$_REQUEST['id']."'");
 		$mytype="update";
 		$myid=$_REQUEST['id'];

 	}
 	else
 	{
 		$mytype="add";
 		$myid='0';
 	}
 ?>
    <div class="page-bar">
        <ul class="page-breadcrumb">
            <li>
                <a href="?page=home">Home</a>
                <i class="fa fa-circle"></i>
            </li>
            <li>
                <span>Add Our Works</span>
            </li>
        </ul>

    </div>
    <!-- END PAGE BAR -->

    <!-- END PAGE HEADER-->
    <div class="row">
        <div class="col-md-12">
            <div class="tabbable-line boxless tabbable-reversed">

                <div class="tab-content">
                    <div class="tab-pane active" id="tab_0">
                        <div class="portlet box green">
                            <div class="portlet-title">
                                <div class="caption"> Add Our Works
                                </div>
                            </div>
                            <div class="portlet-body form">
                                <!-- BEGIN FORM-->
                                <form id="formid" class="form-horizontal" enctype="multipart/form-data">
                                    <input type="hidden" name="mytype" id="mytype" value="<?php echo $mytype; ?>">
                                    <input type="hidden" name="myid" id="myid" value="<?php echo $myid; ?>">

                                    <div class="form-body">
                                        <div class="form-group">
                                            <label class="col-md-3 control-label">Project Name</label>
                                            <div class="col-md-4">
                                                <input type="text" class="form-control" name="project_name" value="<?php if(isset($_REQUEST['id'])){ echo $addourworks->project_name; }?>">
                                            </div>
                                        </div>
                                      <div class="form-group">
                                            <label class="col-md-3 control-label" >Add Platform</label>
                                                <div class="col-md-4">
                                                        <select class="bs-select form-control" name="platform">
                                                            <option value="application">APPLICATION</option>
                                                            <option value="web">WEB</option>
                                                            <option value="mobile">MOBILE</option>
                                                        </select>
                                                    </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="col-md-3 control-label">Site URL</label>
                                            <div class="col-md-4">
                                                <input type="text" class="form-control" name="site_url" value="<?php if(isset($_REQUEST['id'])){ echo $addourworks->site_url; }?>">
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="col-md-3 control-label">Playstore URL</label>
                                            <div class="col-md-4">
                                                <input type="text" class="form-control" name="playstore_url" value="<?php if(isset($_REQUEST['id'])){ echo $addourworks->playstore_url; }?>">
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="col-md-3 control-label">IOS URL</label>
                                            <div class="col-md-4">
                                                <input type="text" class="form-control" name="ios_url" value="<?php if(isset($_REQUEST['id'])){ echo $addourworks->ios_url; }?>">
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="col-md-3 control-label">Image</label>
                                            <div class="col-md-4">
                                                <div class="fileinput fileinput-new" data-provides="fileinput">
                                                    <div class="fileinput-new thumbnail" style="width: 200px; height: 150px;">
                                                        <?php 
													if(isset($_REQUEST['id']))
													{
														$editimg=$addourworks->image;
														$src="views/ourworks/".$editimg;
													}
													else
													{
														$editimg='';
														$src="img/no-img.png";
													}
											?>
                                                            <input type="hidden" name="editimg" id="editimg" value="<?php echo $editimg; ?>">
                                                            <img src="<?php echo $src; ?>" alt="" /> </div>
                                                    <div class="fileinput-preview fileinput-exists thumbnail" style="max-width: 200px; max-height: 150px;"> </div>
                                                    <div>
                                                        <span class="btn default btn-file">
                                                                    <span class="fileinput-new"> Select image </span>
                                                        <span class="fileinput-exists"> Change </span>
                                                        <input type="file" id="uploadimg" name="uploadimg"> </span>
                                                        <a href="javascript:;" class="btn red fileinput-exists" data-dismiss="fileinput"> Remove </a>
                                                    </div>
                                                </div>

                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="col-md-3 control-label">About Project</label>
                                            <div class="col-md-4">
                                                <textarea type="text" class="form-control" name="about_project">
                                                    <?php if(isset($_REQUEST['id'])){ echo $addourworks->about_project; }?>
                                                </textarea>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="col-md-3 control-label">Role</label>
                                            <div class="col-md-4">
                                                <textarea type="text" class="form-control" name="role">
                                                    <?php if(isset($_REQUEST['id'])){ echo $addourworks->role; }?>
                                                </textarea>
                                            </div>
                                        </div>
                                       <div class="form-group">
                                        <label class="control-label col-md-3">Deliverables</label>
                                        <div class="col-md-9">
                                            <select multiple="multiple" class="multi-select" id="my_multi_select1" name="my_multi_select1[]">
                                                <?php   $exparr=explode(',', $addourworks->deliverables);  ?>
                                                <option value="Website design" <?php  if(in_array('Website design',$exparr)){ echo 'selected="selected"';} ?>>Website design</option>
                                                <option <?php  if(in_array('Website Development',$exparr)){ echo 'selected="selected"';} ?> value="Website Development">Website Development</option>
                                                <option <?php  if(in_array('SEO',$exparr)){ echo 'selected="selected"';} ?> value="SEO" >SEO</option>
                                                <option <?php  if(in_array('SEO Marketting',$exparr)){ echo 'selected="selected"';} ?> value="SEO Marketting" >SEO Marketting</option>
                                                <option <?php  if(in_array('Email Marketting',$exparr)){ echo 'selected="selected"';} ?> value="Email Marketting">Email Marketting</option>
                                                <option <?php  if(in_array('Content Marketting',$exparr)){ echo 'selected="selected"';} ?> value="Content Marketting">Content Marketting</option>
                                                <option <?php  if(in_array('Logo Design',$exparr)){ echo 'selected="selected"';} ?> value="Logo Design">Logo Design</option>
                                                <option <?php  if(in_array('innerPage Design',$exparr)){ echo 'selected="selected"';} ?> value="innerPage Design">innerPage Design</option>
                                                <option <?php  if(in_array('Social Plugings',$exparr)){ echo 'selected="selected"';} ?> value="Social Plugings">Social Plugings</option>
                                                <option <?php  if(in_array('wordpress sites',$exparr)){ echo 'selected="selected"';} ?> value="wordpress sites">wordpress sites </option>
                                                <option <?php  if(in_array('App development',$exparr)){ echo 'selected="selected"';} ?> value="App development">App development</option>
                                                <option <?php  if(in_array('Android App',$exparr)){ echo 'selected="selected"';} ?> value="Android App">Android App</option>
                                                <option <?php  if(in_array('Ios App',$exparr)){ echo 'selected="selected"';} ?> value="Ios App">Ios App</option>
                                                <option <?php  if(in_array('eCommerce',$exparr)){ echo 'selected="selected"';} ?> value="eCommerce">eCommerce</option>
                                            </select>
                                        </div>
                                    </div>
                                        <div class="form-group">
                                            <label class="col-md-3 control-label">Testimonials</label>
                                            <div class="col-md-4">
                                                <textarea type="text" class="form-control" name="testimonials">
                                                    <?php if(isset($_REQUEST['id'])){ echo $addourworks->testimonials; }?>
                                                </textarea>
                                            </div>
                                        </div>

                                        <div class="form-group">
                                            <label class="col-md-3 control-label">Visible</label>
                                            <div class="col-md-4">
                                                <div class="input-icon">
                                                    <?php
											if(isset($_REQUEST['id']))
											{
												if($addourworks->visible=='1')
												{
													$checked='checked="checked"';
													$checkval="1";
												}                         	
												else
												{
													$checked='';
													$checkval="0";
												}
											 }
											 else
											{
												$checked='';
												$checkval="0";
											}
											?>
                                                        <input type="checkbox" id="myvisible" class="make-switch" <?php echo $checked; ?> data-on-color="success" data-off-color="danger" onchange="changestatus()"> </div>
                                            </div>
                                            <div id="console-event">
                                                <input type="hidden" name="visible_mt" id="visible_mt" value="<?php echo $checkval; ?>">
                                            </div>
                                        </div>

                                        <div class="form-group">
                                            <div id="loader" style="text-align:center;display:none;">

                                            </div>
                                        </div>

                                    </div>
                                    <div class="form-actions">
                                        <div class="row">
                                            <div class="col-md-offset-3 col-md-9">
                                                <button type="submit" class="btn btn-square green">Submit</button>
                                                <button type="button" class="btn btn-square grey-salsa btn-outline">Cancel</button>
                                            </div>
                                        </div>
                                    </div>

                                </form>
                                <!-- END FORM-->

                            </div>
                        </div>

                    </div>

                </div>
            </div>
        </div>
    </div>
    <script>
        function changestatus() {

            if ($('#myvisible').prop('checked') == true) {
                var visible = "1";
            } else {
                var visible = "0";
            }

            $('#console-event').html('<input type="hidden" name="visible_mt" id="visible_mt" value="' + visible + '">');
        }

        $("#formid").validate({
            ignore: ":hidden",
            rules: {

            },
            messages: {

            },
            submitHandler: function(form) {
                $("div#loader").addClass('show');

                var form_data = new FormData();
                var file_data = $('#uploadimg')[0].files;
                form_data.append("file_0", file_data[0]);

                var other_data = $('form#formid').serializeArray();
                $.each(other_data, function(key, input) {
                    form_data.append(input.name, input.value);
                });
                $.ajax({
                    url: "?page=ourworks_ajax",
                    type: "POST",
                    data: form_data,
                    cache: false,
                    contentType: false,
                    processData: false,
                    success: function(response) {
                        $("div#loader").removeClass('show');
                        if (response == 'success') {
                            window.location.href = "?page=ourworks";
                        }
                    }
                });
                return false;
            }

        });
  </script>