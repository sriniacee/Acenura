<div class="page-bar">
<ul class="page-breadcrumb">
    <li>
        <a href="?page=home">Home</a>
        <i class="fa fa-circle"></i>
    </li>
    <li>
       <span>Detailed Requirement</span>
    </li>
    
</ul>

</div>
<div class="row">
<div class="col-md-12">
    <!-- BEGIN EXAMPLE TABLE PORTLET-->
    <div class="portlet light bordered">
        <div class="portlet-title">
            <div class="caption">
                <i class="icon-settings font-red"></i>
                <span class="caption-subject font-red sbold uppercase">Detailed Requirement</span>
            </div>
        </div>
        <div class="portlet-body">

            </div>
            <table class="table table-striped table-bordered table-hover table-checkable order-column " id="sample_1">
                <thead>
                    <tr>
                        <th> Sl </th>
                        <th> Name </th>
                        <th> Email </th>
                        <th> Contact</th>
                        <th> Requirement Category  </th>
                        <th> Message </th>
                        <th> Reg Date </th>
                    </tr>
                </thead>
                <tbody>
                <?php
                    $i=1;
                    $contdet=$functions->get_result("SELECT * FROM `det_require` WHERE `is_deleted`=0 ORDER BY id DESC ");
                    foreach($contdet as $cont)
                     {                                
                     ?>
                    <tr>
                        <td> <?php echo $i; ?> </td>
                        <td> <?php echo $cont->name; ?> </td>
                        <td> <?php echo $cont->email; ?>   </td>
                        <td> <?php echo $cont->contact; ?> </td>
                        <td> <?php echo $cont->category; ?> </td>
                        <td> <?php echo $cont->message; ?>   </td>
                        <td><?php echo date("d-m-Y",$cont->Reg_date); ?></td>
                    </tr>
                    <?php $i++; } ?>
                </tbody>
            </table>
        </div>
    </div>
    <!-- END EXAMPLE TABLE PORTLET-->
</div>
</div>


