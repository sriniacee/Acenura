<!DOCTYPE html>
<html lang="en">
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<head>
        <meta charset="utf-8" />
        <meta charset="utf-8" />
        <title>ACENURA | Admin Dashboard</title>
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta content="width=device-width, initial-scale=1" name="viewport" />
        <!-- BEGIN GLOBAL MANDATORY STYLES -->
        <link href="https://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700&amp;subset=all" rel="stylesheet" type="text/css" />
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <link href="css/simple-line-icons.min.css" rel="stylesheet" type="text/css" />
        <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css" />
        <link href="css/bootstrap-switch.min.css" rel="stylesheet" type="text/css" />
        <!-- END GLOBAL MANDATORY STYLES -->
		
        <!-- BEGIN PAGE LEVEL PLUGINS -->
        <link href="css/daterangepicker.min.css" rel="stylesheet" type="text/css" />
		 <link href="css/bootstrap-datepicker3.min.css" rel="stylesheet" type="text/css" />
        <link href="css/bootstrap-timepicker.min.css" rel="stylesheet" type="text/css" />
        <link href="css/bootstrap-datetimepicker.min.css" rel="stylesheet" type="text/css" />
		<link href="css/clockface.css" rel="stylesheet" type="text/css" />
        <link href="css/morris.css" rel="stylesheet" type="text/css" />
        <link href="css/fullcalendar.min.css" rel="stylesheet" type="text/css" />
        <link href="css/jqvmap.css" rel="stylesheet" type="text/css" />
       	<link href="css/bootstrap-wysihtml5.css" rel="stylesheet" type="text/css" />
		<link href="css/bootstrap-markdown.min.css" rel="stylesheet" type="text/css" />
		<link href="css/summernote.css" rel="stylesheet" type="text/css" />

        <!-- END PAGE LEVEL PLUGINS -->
		
       
        <!-- BEGIN THEME GLOBAL STYLES -->
        <link href="css/components.min.css" rel="stylesheet" id="style_components" type="text/css" />
        <link href="css/plugins.min.css" rel="stylesheet" type="text/css" />
        <!-- END THEME GLOBAL STYLES -->
        <!-- BEGIN THEME LAYOUT STYLES -->
        <link href="css/layout.min.css" rel="stylesheet" type="text/css" />
        <link href="css/darkblue.min.css" rel="stylesheet" type="text/css" id="style_color" />
        <link href="css/custom.min.css" rel="stylesheet" type="text/css" />
        <link href="css/bootstrap-fileinput.css" rel="stylesheet" type="text/css" />
		
	
		
		<?php if(isset($_REQUEST['page']) && $_REQUEST['page']=='login') { ?>
		<link href="css/select2.min.css" rel="stylesheet" type="text/css" />
        <link href="css/select2-bootstrap.min.css" rel="stylesheet" type="text/css" />		
        <link href="css/login.min.css" rel="stylesheet" type="text/css" />
		 
		<?php } ?>
        <!-- END THEME LAYOUT STYLES -->
        <link rel="shortcut icon" href="favicon.ico" /> </head>
		
		<script src="js/jquery.min.js" type="text/javascript"></script>
		<script src="js/bootstrap.min.js" type="text/javascript"></script>
		<script src="js/jquery.validate.js" type="text/javascript"></script>
		
		<script src="js/wysihtml5-0.3.0.js" type="text/javascript"></script>
		<script src="js/bootstrap-wysihtml5.js" type="text/javascript"></script>
		<script src="js/markdown.js" type="text/javascript"></script>
		<script src="js/bootstrap-markdown.js" type="text/javascript"></script>
		<script src="js/summernote.min.js" type="text/javascript"></script>
		
	
    <!-- END HEAD -->
	<style>
	input[type="text"].error
	{
		border:1px solid #E93842;
	}
	input[type="url"].error
	{
		border:1px solid #E93842;
	}
	.error {
		color:#E93842;
		/*border:1px solid red; */
	}
	
	#loader
	{
		display : none;
	}
	#loader.show
	{
		display : block;
		position : fixed;
		z-index: 100;
		background-image : url('img/loader.gif');
		background-color:#666;
		opacity : 0.4;
		background-repeat : no-repeat;
		background-position : center;
		left : 0;
		bottom : 0;
		right : 0;
		top : 0;
	}
	#loadinggif.show
	{
		left : 50%;
		top : 50%;
		position : absolute;
		z-index : 101;
		width : 32px;
		height : 32px;
		margin-left : -16px;
		margin-top : -16px;
	}
	</style>
    <body class="page-header-fixed page-footer-fixed page-sidebar-closed-hide-logo page-content-white">

        <?php
		$qrystring=explode("&",$_SERVER['QUERY_STRING']);
		
if($qrystring[0]!='')
{
	$pgname='?'.$qrystring[0];
}
else
{
	$pgname='?page=home';
}

        $controllers->start();
        if ((!isset($_SESSION['username']) || $_SESSION['username'] == '') && $page!='login')
        {
        echo '<script>window.location.href="?page=login";</script>';

        }
		
         ?>
		<input type="hidden" id="pgname" value="<?php echo $pgname; ?>">
        <div class="page-wrapper">
            <!-- BEGIN HEADER -->
            <div class="page-header navbar navbar-fixed-top">
                <!-- BEGIN HEADER INNER -->
                <div class="page-header-inner ">
                    <!-- BEGIN LOGO -->
                    <div class="page-logo">
                        <a href="?page=home">
                            <img src="img/logo.png" alt="logo" class="logo-default" style="width: 150px;" /> </a>
                        <div class="menu-toggler sidebar-toggler">
                            <span></span>
                        </div>
                    </div>
                    <!-- END LOGO -->
                    <!-- BEGIN RESPONSIVE MENU TOGGLER -->
                    <a href="javascript:;" class="menu-toggler responsive-toggler" data-toggle="collapse" data-target=".navbar-collapse">
                        <span></span>
                    </a>
                    <!-- END RESPONSIVE MENU TOGGLER -->
                    <!-- BEGIN TOP NAVIGATION MENU -->
                    <div class="top-menu">
                        <ul class="nav navbar-nav pull-right">
                           
                          
                            
                            <!-- BEGIN USER LOGIN DROPDOWN -->
                            <!-- DOC: Apply "dropdown-dark" class after below "dropdown-extended" to change the dropdown styte -->
                            <li class="dropdown dropdown-user">
                                <a href="javascript:;" class="dropdown-toggle" data-toggle="dropdown" data-hover="dropdown" data-close-others="true">
                                    <img alt="" class="img-circle" src="img/avatar3_small.jpg" />
                                    <span class="username username-hide-on-mobile"> Nick </span>
                                    <i class="fa fa-angle-down"></i>
                                </a>
                                <ul class="dropdown-menu dropdown-menu-default">
                                   
                                    <li>
                                        <a onclick="logOut()">
                                            <i class="icon-key"></i> Log Out </a>
                                    </li>
                                </ul>
                            </li>
                        </ul>
                    </div>
                    <!-- END TOP NAVIGATION MENU -->
                </div>
               
            </div>
           
            <div class="clearfix"> </div>
            <!-- END HEADER & CONTENT DIVIDER -->
            <!-- BEGIN CONTAINER -->
            <div class="page-container">
                <!-- BEGIN SIDEBAR -->
                <div class="page-sidebar-wrapper">
                  
                    <div class="page-sidebar navbar-collapse collapse" id="menu">
                     
                        <ul class="page-sidebar-menu  page-header-fixed " data-keep-expanded="false" data-auto-scroll="true" data-slide-speed="200" style="padding-top: 20px;height: 620px;">
                          
                            <li class="sidebar-toggler-wrapper hide">
                                <div class="sidebar-toggler">
                                    
                                </div>
                            </li>
                             <li class="heading">
                                <h3 class="uppercase">Our Works</h3>
                            </li>
                            <li class="nav-item <?php if($pgname=='?page=home'){ echo 'active'; } ?>">
                                <a href="?page=home" class="nav-link nav-toggle">
                                    <i class="icon-home"></i>
                                    <span class="title">Dashboard</span>
                                </a>                                
                            </li>
							 <li  class="nav-item <?php if($pgname=='?page=ourworks'){ echo 'active'; } ?>">
                                <a href="?page=ourworks" class="nav-link nav-toggle">
                                    <i class="icon-grid" aria-hidden="true"></i>
                                    <span class="title">Our Works</span>
                                </a>                                
                            </li>
                            <li class="heading">
                                <h3 class="uppercase">Contact Forms</h3>
                            </li>
                         <li class="nav-item <?php if($pgname=='?page=getintouch'){ echo 'active'; } ?>">
                                <a href="?page=getintouch" class="nav-link nav-toggle">
                                    <i class="fa fa-bandcamp"></i>
                                    <span class="title">Get in Touch</span>
                                    
                                </a>
                                
                            </li>
                            <li class="nav-item <?php if($pgname=='?page=detailed_requirement'){ echo 'active'; } ?>">
                                <a href="?page=detailed_requirement" class="nav-link nav-toggle">
                                    <i class="fa fa-product-hunt"></i>
                                    <span class="title">Requirement Details</span>
                                    
                                </a>
                                
                            </li>
				
                        </ul>
                        <!-- END SIDEBAR MENU -->
                        <!-- END SIDEBAR MENU -->
                    </div>
                    <!-- END SIDEBAR -->
                </div>
                <!-- END SIDEBAR -->
                <!-- BEGIN CONTENT -->
                <div class="page-content-wrapper">
                    <!-- BEGIN CONTENT BODY -->
                    <div class="page-content">
                        <!-- BEGIN PAGE HEADER-->
                        <!-- BEGIN THEME PANEL -->
                
                        <!-- END THEME PANEL -->
<script>

function logOut()
{	
	var type="logout";	
	$.ajax({		
		url:"?page=login_ajax",		
		type:"POST",		
		data:{type:type},		
		success:function(data)		
		{			
			if(data=='success')			
			{				
				window.location.href="?page=login";			
			}		
		}		
	});
}</script>
