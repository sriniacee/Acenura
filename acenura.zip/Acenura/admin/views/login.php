<!DOCTYPE html>
<html lang="en">
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<head>
        <meta charset="utf-8" />
        <title>ACENURA -ADMIN </title>
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta content="width=device-width, initial-scale=1" name="viewport" />
		
        <link href="https://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700&amp;subset=all" rel="stylesheet" type="text/css" />
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        
        <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css" />
        <link href="css/bootstrap-switch.min.css" rel="stylesheet" type="text/css" />
       
        
        <link href="css/login.min.css" rel="stylesheet" type="text/css" />
        <!-- END PAGE LEVEL STYLES -->
        <!-- BEGIN THEME LAYOUT STYLES -->
        <!-- END THEME LAYOUT STYLES -->
        <link rel="shortcut icon" href="favicon.ico" /> </head>
    <!-- END HEAD -->
	<style>
	input[type="text"].error
	{
		border:1px solid #E93842;
	}
	input[type="url"].error
	{
		border:1px solid #E93842;
	}
	.error {
		color:#E93842;
		/*border:1px solid red; */
	}
	.btn
	{
		background-color: #2d8e5d  !important;
	}
	</style>

    <body class=" login">
        <!-- BEGIN LOGO -->
        <div class="logo">
            <a href="index-2.html">
                <img src="img/logo.png" alt="" /> </a>
        </div>
        <!-- END LOGO -->
        <!-- BEGIN LOGIN -->
        <div class="content">
            <!-- BEGIN LOGIN FORM -->		
            <form id="formid">				<input type="hidden" name="type" id="type" value="login">
                <h3 class="form-title font-green">Sign In</h3>
					<div class="alert alert-danger display-hide" id="invalid" style="display:none">						<span> Enter any username and password. </span>					</div>
                <div class="form-group">
                    <!--ie8, ie9 does not support html5 placeholder, so we just show field title for that-->
                    <label class="control-label visible-ie8 visible-ie9">Username</label>
                    <input class="form-control form-control-solid placeholder-no-fix" type="text" autocomplete="off" placeholder="Username" name="username" /> </div>
                <div class="form-group">
                    <label class="control-label visible-ie8 visible-ie9">Password</label>
                    <input class="form-control form-control-solid placeholder-no-fix" type="password" autocomplete="off" placeholder="Password" name="password" /> </div>
                <div class="form-actions" style="text-align: center;">
                    <button type="submit" class="btn green uppercase">Login</button>
                </div>


            </form>
            <!-- END LOGIN FORM -->
          
            <!-- END REGISTRATION FORM -->
        </div>
        <div class="copyright"> <?php echo date('Y'); ?> © PHARMACY. Admin Dashboard. </div>

        <!-- BEGIN CORE PLUGINS -->
        <script src="js/jquery.min.js" type="text/javascript"></script>
        <script src="js/bootstrap.min.js" type="text/javascript"></script>
       
        <script src="js/login.min.js" type="text/javascript"></script>

        <script src="js/jquery.validate.js" type="text/javascript"></script>

<script>

$("#formid").validate({	ignore: ":hidden",
	rules: 
	{
		username:
		{
			required:true
		},
		password:
		{
			required:true
		}
	},
	messages: 
	{
		username:
		{
			required:"Username is required"
		},
		password:
		{
			required:"Password is required"
		}
	},
	submitHandler: function (form) 
	{
		var form_data = new FormData();
		var other_data = $('form#formid').serializeArray();
		$.each(other_data,function(key,input)
		{
			form_data.append(input.name,input.value);
		});		
		
		$.ajax
		({
			url:"?page=login_ajax",
			type: "POST",
			data: form_data,
			async: false,
			cache: false,
			contentType: false,
			processData: false,
			success: function( response ) 
			{
			   
                if(response=='success')
                {
                    window.location.href="?page=home";
                }
                else
                {
                    $('#invalid').show().delay(2000).fadeOut();
                }
			}
		});
		return false; 
	}


});


</script>
</body>
</html>