<!-- BEGIN FOOTER -->
<div class="page-footer">
    <div class="page-footer-inner"> <?php echo date("Y"); ?> &copy; PHARMACY STORE.
       
    </div>
    <div class="scroll-to-top">
        <i class="icon-arrow-up"></i>
    </div>
</div>
<!-- END FOOTER -->
</div>
<!-- BEGIN QUICK NAV -->

<div class="quick-nav-overlay"></div>
<!-- END QUICK NAV -->

<!-- BEGIN CORE PLUGINS -->

<script src="js/js.cookie.min.js" type="text/javascript"></script>
<script src="js/jquery.slimscroll.min.js" type="text/javascript"></script>
<script src="js/jquery.blockui.min.js" type="text/javascript"></script>
<script src="js/bootstrap-switch.min.js" type="text/javascript"></script>
<script src="js/bootstrap-fileinput.js" type="text/javascript"></script>
<!-- END CORE PLUGINS -->
<!-- BEGIN PAGE LEVEL PLUGINS -->
<script src="js/moment.min.js" type="text/javascript"></script>
<script src="js/daterangepicker.min.js" type="text/javascript"></script>
<script src="js/bootstrap-datepicker.min.js" type="text/javascript"></script>
<script src="js/bootstrap-timepicker.min.js" type="text/javascript"></script>
<script src="js/bootstrap-datetimepicker.min.js" type="text/javascript"></script>
<script src="js/clockface.js" type="text/javascript"></script>

<script src="js/morris.min.js" type="text/javascript"></script>
<script src="js/raphael-min.js" type="text/javascript"></script>
<script src="js/jquery.waypoints.min.js" type="text/javascript"></script>
<script src="js/jquery.counterup.min.js" type="text/javascript"></script>
<script src="js/amcharts.js" type="text/javascript"></script>
<script src="js/serial.js" type="text/javascript"></script>
<script src="js/pie.js" type="text/javascript"></script>
<script src="js/radar.js" type="text/javascript"></script>
<script src="js/light.js" type="text/javascript"></script>
<!--<script src="js/atterns.js" type="text/javascript"></script> -->
<script src="js/chalk.js" type="text/javascript"></script>
<script src="js/ammap.js" type="text/javascript"></script>
<script src="js/worldLow.js" type="text/javascript"></script>
<script src="js/amstock.js" type="text/javascript"></script>
<script src="js/fullcalendar.min.js" type="text/javascript"></script>
<script src="js/horizontal-timeline.js" type="text/javascript"></script>
<script src="js/jquery.flot.min.js" type="text/javascript"></script>
<script src="js/jquery.flot.resize.min.js" type="text/javascript"></script>
<script src="js/jquery.flot.categories.min.js" type="text/javascript"></script>
<script src="js/jquery.easypiechart.min.js" type="text/javascript"></script>
<script src="js/jquery.sparkline.min.js" type="text/javascript"></script>
<script src="js/jquery.vmap.js" type="text/javascript"></script>
<script src="js/jquery.vmap.russia.js" type="text/javascript"></script>
<script src="js/jquery.vmap.world.js" type="text/javascript"></script>
<script src="js/jquery.vmap.europe.js" type="text/javascript"></script>
<script src="js/jquery.vmap.germany.js" type="text/javascript"></script>
<script src="js/jquery.vmap.usa.js" type="text/javascript"></script>

<script src="js/jquery.validate.js" type="text/javascript"></script>

<script src="js/datatable.js" type="text/javascript"></script>
<script src="js/datatables.min.js" type="text/javascript"></script>
<script src="js/datatables.bootstrap.js" type="text/javascript"></script>


<script src="js/app.min.js" type="text/javascript"></script>
<script src="js/table-datatables-managed.min.js" type="text/javascript"></script>
<script src="js/components-date-time-pickers.min.js" type="text/javascript"></script>
<!-- BEGIN PAGE LEVEL SCRIPTS -->
<script src="js/dashboard.min.js" type="text/javascript"></script>
<?php if(isset($_REQUEST['page']) && $_REQUEST['page']=='login') { ?>
    <script src="js/jquery.vmap.sampledata.js" type="text/javascript"></script>
    <script src="js/additional-methods.min.js" type="text/javascript"></script>
    <script src="js/select2.full.min.js" type="text/javascript"></script>
    <script src="js/login.min.js" type="text/javascript"></script>

    <?php } ?>
        <!-- END PAGE LEVEL SCRIPTS -->
        <!-- BEGIN THEME LAYOUT SCRIPTS -->
        <script src="js/layout.min.js" type="text/javascript"></script>
        <script src="js/demo.min.js" type="text/javascript"></script>
        <script src="js/quick-sidebar.min.js" type="text/javascript"></script>
        <script src="js/quick-nav.min.js" type="text/javascript"></script>
        <!-- END THEME LAYOUT SCRIPTS -->
        <script>
            $(document).ready(function() {
                $('#clickmewow').click(function() {
                    $('#radio1003').attr('checked', 'checked');
                });
            });
        </script>
		
		<script>
		function deleterow(id,page)
		{
		
			var type="deleterow";
			var page="?page="+page;
			if(window.confirm("Do you want delete?"))
			{
				$.ajax({
				url:page,
				type:"post",
				data:{id:id,type:type},
				success:function(data)
				{
				  if(data=='success')
				  {
					location.reload();
				  }
				}
				});
			}

		}
		</script>
        </body>

        </html> 