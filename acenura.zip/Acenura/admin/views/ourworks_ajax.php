<?php
if(@$_REQUEST['type']=='deleterow')
{
	$deleterow=$functions->set_query("UPDATE `ourworks` SET created_by='".time()."' , is_deleted='1' WHERE id='".$_REQUEST['id']."'");
	echo "success";
}
else
{		
		$editimg=$_REQUEST['editimg'];
		$file='file_0';
		
			if (isset($_FILES[$file]) && $_FILES[$file]['error']== 0 ) 
			{
				@$imgpath=date('dmyhis');
				@$temp = explode(".", $_FILES[$file]["name"]);
				@$imgname = $imgpath . '.' . end($temp);
				if(move_uploaded_file(@$_FILES[$file]['tmp_name'], 'views/ourworks/' . $imgname))
				{
					$uri=$imgname;			
				}
				else
				{
					$uri=$_REQUEST['editimg'];
				}
			}
			else 
			{	

				$uri=$_REQUEST['editimg'];
			}

		$project_name=$functions->escape_string($_REQUEST['project_name']);
		$platform=$_REQUEST['platform'];
		$site_url=$functions->escape_string($_REQUEST['site_url']);
		$playstore_url=$functions->escape_string($_REQUEST['playstore_url']);
		$ios_url=$functions->escape_string($_REQUEST['ios_url']);
		$about_project=trim($functions->escape_string($_REQUEST['about_project']));
		$role=trim($functions->escape_string($_REQUEST['role']));
		$deliverable=implode(',', $_REQUEST['my_multi_select1']);
		$testimonials=trim($functions->escape_string($_REQUEST['testimonials']));
		$visible=$_REQUEST['visible_mt'];



		if($_REQUEST['mytype']=='add')
		{	
			$insert_banner=$functions->set_query("INSERT INTO `ourworks`(`project_name`,`platform`, `site_url`, `playstore_url`, `ios_url`, `image`, `about_project`, `role`, `deliverables`, `testimonials`, `visible`,`created_by`) VALUES ('".$project_name."','".$platform."','".$site_url."','".$playstore_url."','".$ios_url."','".$uri."','".$about_project."','".$role."','".$deliverable."','".$testimonials."','".$visible."','".time()."')");

			
			
			if($insert_banner)
			{
				echo "success";
			}
			else
			{
				echo "error";
			}
		}
		else
		{	
			
			$insert_banner=$functions->set_query("UPDATE `ourworks` SET `project_name`='".$project_name."',`platform`='".$platform."',`site_url`='".$site_url."',`playstore_url`='".$playstore_url."',`ios_url`='".$ios_url."',`image`='".$uri."',`about_project`='".$about_project."',`role`='".$role."',`deliverables`='".$deliverable."',`testimonials`='".$testimonials."',`visible`='".$visible."',`created_by`='".time()."' WHERE id='".$_REQUEST['myid']."'");

			echo "success";

			}
		
}		
?>