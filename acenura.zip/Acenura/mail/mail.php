<?php
//error_reporting(E_STRICT);
date_default_timezone_set('Asia/Kolkata');
require_once('class.phpmailer.php');

function mailer($to_m,$ton_m,$body_m,$sub_m,$file=0){
/*
$domain='nscript.in';
$password='d3P*DZhh'; */
$domain='gmail.com';
$password='gvdinesh';
$company='ACE NURA';

$mail             = new PHPMailer();
//$body             = preg_replace("[\]",'',$body);
$mail->IsSMTP(); 
$mail->SMTPDebug  = 1;            // 1 = errors and messages ,2 = messages only
$mail->SMTPAuth   = true;                 
$mail->SMTPSecure = "ssl";                 
$mail->Host       = "smtp.gmail.com"; 
$mail->Port       = 465;                  
$mail->Username   = "dinesh.acee@".$domain;   
$mail->Password   = $password;            
$mail->SetFrom("dinesh.acee@{$domain}",$company);
$mail->AddReplyTo("dinesh.acee@{$domain}",$company);
$mail->Subject    = $sub_m;
$mail->AltBody    = "To view the message, please use an HTML compatible email viewer!";
$mail->MsgHTML($body_m);
$address = $to_m;
$mail->AddAddress($address, $ton_m);

if($file!=0){
	foreach($file as $filename=>$filet){
$mail->AddAttachment($filet, $filename);
}}

if(!$mail->Send()) { echo "Mailer Error: " . $mail->ErrorInfo;} else {
  //echo "Message sent!";
}}

//mailer('naresh@nscript.in','Naveen Margan','THis is sample body','THis is subject');
?>