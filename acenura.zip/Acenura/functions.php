<?php
/**
* Author : Dinesh G ,Web Developer - Acenura

*/
class functions extends db
{
	
	public function passwordgenerate($length) // Password Generation 
	{
		$chars = "0123456789abcdefghjkmnpqrstuvwxyz!@#$%&*?ABCDEFGHIJKLMNOPQRSTUVWXYZ";
		$generatepwd = "";
		for ($i = 1; $i <=$length; $i++) 
		{
			$generatepwd.= $chars[mt_rand(0, strlen($chars)-1)];
		}
		return $generatepwd;
	}
	public function sentmail($to,$toname,$message,$subject,$file) // Mail Send Function
	{
		
		date_default_timezone_set('Asia/Kolkata');
		require_once('mail/class.phpmailer.php');
		
		$host="smtp.gmail.com"; 
		$domain='gmail.com';
		$password='Acenura@123';
		$company=$subject;
		
		$mail             = new PHPMailer();
		//$body             = preg_replace("[\]",'',$body);
		$mail->IsSMTP(); 
		$mail->SMTPDebug  = 1;            // 1 = errors and messages ,2 = messages only
		$mail->SMTPAuth   = true;                 
		$mail->SMTPSecure = "ssl";                 
		$mail->Host       = $host;
		$mail->Port       = 465;                  
		$mail->Username   = "acenurademo@".$domain;   
		$mail->Password   = $password;            
		$mail->SetFrom("acenurademo@{$domain}",$company);
		$mail->AddReplyTo("acenurademo@{$domain}",$company);
		$mail->Subject    = $subject;
		$mail->AltBody    = "To view the message, please use an HTML compatible email viewer!";
		$mail->MsgHTML($message);
		$address = $to;
		$mail->AddAddress($address, $toname);
		//$mail->AddAttachment('../pdf/test.pdf', 'IGLA Brochure.pdf');
		if($file!=0){
			foreach($file as $filename=>$filet){
		$mail->AddAttachment($filet, $filename);
		}}
		if(!$mail->Send()) { return "Mailer Error: " . $mail->ErrorInfo;} else {
		
		  return "success";
		}
		
	}
	public function invoice_create($order_date,$order_number,$billingaddress,$shippingaddress,$product_desc,$quantity,$unit_cost,$product_amount,$total_amount) // Invoice Creation
	{
			
		require('pdfgenerate/invoice.php');
		
		$watermark="Shoppadala Invoice";		
		$ourcompany="Aceventurees";
		$invoice_title="Shoppadala Invoice";
		$our_addr="49,Nerkundrampathai,vadapalani\n837949596";
		
		$pdf = new PDF_Invoice( 'P', 'mm', 'A4' );	
		$pdf->AddPage();
		$pdf->addSociete($ourcompany,$our_addr);
		
		if($watermark!='')
		{
			$pdf->temporaire($watermark); 
		}
		
		$pdf->addDate( "Date : ".$order_date."\nOrder Number : ".$order_number);
		$pdf->SetFont('Arial','B',18);
		$pdf->Cell(80);
		$pdf->Cell(20,20,$invoice_title,0,1,'C');
		$pdf->SetFont('Arial','B',12);
		$pdf->Cell(15);
		$pdf->Cell(20,5,'Customer Information',0,1,'C');
		$pdf->addBillingAddr($billingaddress);
		$pdf->addShippingAddr($shippingaddress);
		$cols=array( "Sno"    => 23,
					 "Description"  => 78,
					 "Qty"     => 22,
					 "Rate/Unit ($)"      => 26,
					 "Amount ($)" => 41);
		$pdf->addCols( $cols);
		$cols=array("Sno"    => "C",
					 "Description"  => "C",
					 "Qty"     => "C",
					 "Rate/Unit ($)"      => "C",
					 "Amount ($)" => "C");
		$pdf->addLineFormat( $cols);
		$pdf->addLineFormat($cols);
		$y    = 100;
		$sno = 1;	
	
		foreach($product_desc AS $key=>$val) 
		{
			$line = array( "Sno"    => $sno,
               "Description"  => $product_desc[$key],
               "Qty"     => $quantity[$key],
               "Rate/Unit ($)"      => $unit_cost[$key],
               "Amount ($)" => $product_amount[$key]);
			$size = $pdf->addLine( $y, $line );
			$y   += $size + 4;
			$sno++;
		}		
		$sub_total_details = array("final_amount"=>$total_amount);
		
		$pdf->addSubTotals($sub_total_details);
		$time = time();
		$file_name = "INV".$time.".pdf";
		$filepath="invoices/".$file_name;
		$pdf->Output($filepath,"F");
		return $file_name;

	}
	function serverip() // Find IP Address
	{
		$ipaddress;
		if (getenv("HTTP_CLIENT_IP"))
		$ipaddress = getenv("HTTP_CLIENT_IP");
		else if(getenv("HTTP_X_FORWARDED_FOR"))
		$ipaddress = getenv("HTTP_X_FORWARDED_FOR");
		else if(getenv("REMOTE_ADDR"))
		$ipaddress = getenv("REMOTE_ADDR");
		else
		$ipaddress = "UNKNOWN";
		return $ipaddress;
	}
}
?>