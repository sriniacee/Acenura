<?php include 'header.php';?>
<section id="servicebanner">
    <div class="container-fluid">
        <div class="container my-auto">
            <h2 class="text-left my-auto">OUR WORKS</h2>
        </div>
        
    </div>
</section>
<section id="service1">
    <div class="container">
        <div class="row">
            <div class="col-12 col-sm-12 col-md-6 col-lg-6">
                <h3>EXAMPLE PROJECT NAME</h3>
                <p>Visit Site:<a href="#">acenura.com</a></p>
            </div>
            <div class="col-12 col-sm-12 col-md-6 col-lg-6">
                <img src="img/Banner2.jpg" alt="" width="500px">
            </div>
        </div>
    </div>
</section>
<section id="service2">
    <div class="container">
        <div class="row">
            <div class="col-12 col-sm-12 col-md-12 col-lg-12">
                <h2>ABOUT PROJECT</h2>
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
                quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
                consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
                cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
                proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
                quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
                consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
                cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
                proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
            </div>
        </div>
    </div>
</section>
<section id="service3">
    <div class="container-fluid">
        <div class="row">
            <div class="col-12 col-sm-12 col-md-8 col-lg-8">
                <div class="role">
               <h2>ROLES</h2>
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
                quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
                consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
                cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
                proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
                </div>
             </div>
            <div class="col-12 col-sm-12 col-md-4 col-lg-4">
                <div class="role2">
                <h2>DELIVERABLES</h2>
                <p>Website design</p>
                <p>Website Development</p>
                <p>SEO</p>
                <p>Email Marketting</p>
                <p>Content Marketting</p>
            </div>
            </div>
        </div>
    </div>
</section>
<section id="service4">
    <div class="container">
        <h2>TESTIMONIALS</h2>
        <blockquote class="blockquote"><p>"Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
        tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
        quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
        consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
        cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
        proident, sunt in culpa qui officia deserunt mollit anim id est laborum."</p></blockquote>
    </div>
</section>
<section id="whatwedo">
    <div class="container wedo">
            <h2 class="text-center"><strong>WHAT WE DO</strong></h2>
        <div class="row">
            <div class="col-sm-12 col-md-4 col-lg-4 col-xl-4">
                <div class="card cardwe">
                    <img class="cardwe-img-top" src="img/DesignStatt.png" alt="Cardwe image cap">
                    <div class="cardwe-block">
                        <h3 class="cardwe-title text-center">DESIGN</h3>
                        <p class="cardwe-text text-center">We give your over-all design a plan of action to achieve excellence.</p>
                    </div>
                </div>              
            </div>
            <div class="col-sm-12 col-md-4 col-lg-4 col-xl-4">
                <div class="card cardwe">
                    <img class="cardwe-img-top" src="img/DesignStatt.png" alt="Cardwe image cap">
                    <div class="cardwe-block">
                        <h3 class="cardwe-title text-center">DEVELOPMENT</h3>
                        <p class="cardwe-text text-center">We give your over-all design a plan of action to achieve excellence.</p>
                    </div>
                </div>
            </div>
            <div class="col-sm-12 col-md-4 col-lg-4 col-xl-4">
                <div class="card cardwe">
                    <img class="cardwe-img-top" src="img/DesignStatt.png" alt="Cardwe image cap">
                    <div class="cardwe-block">
                        <h3 class="cardwe-title text-center">DIGITAL MARKETTING</h3>
                        <p class="cardwe-text text-center">We give your over-all design a plan of action to achieve excellence.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<section id="service5">
    <div class="container">
        <div class="row">
            <div class="col-sm-12 col-md-12 col-lg-8 col-xl-8 mx-auto">
                <h4 class="text-center">There's nothing better than a place<br>Where imagination is turned into reality.</h4>
                <p class="text-center">if you are need to more Information</p>
            </div>
            <div class="col-sm-12 col-md-12 col-lg-2 col-xl-2 my-auto">
                <p class="text-center"><a href="index.html#contact" class="btn btn-outline-primary mx-auto ">CONTACT US</a></p>
            </div>
        </div>
    </div>
</section>
<?php include 'footer.php';?>