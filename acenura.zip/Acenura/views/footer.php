<footer>
    <div class="container-fluid">
        <div class="footer-top">
            <div class="container">
                <div class="row">
                    <div class="col-xs-12 col-sm-6 col-lg-6 col-md-6">
                        <img src="img/logo.png" class="img-fluid" alt="logo">
                    </div>
                    <div class="col-xs-12 col-sm-6 col-lg-6 col-md-6">
                        <div class="text-center center-block" id="demo-2">
                            <a href="#" class="social fa fa-facebook"></a>
                            <a href="#" class="social fa fa-linkedin"></a>
                            <a href="#" class="social fa fa-google"></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="footer-bottom">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-xs-12 col-sm-6 col-lg-6 col-md-6">
                        <p class="text-right">COPYRIGHT &copy; 2017 ACENURA.COM</p>
                    </div>
                    <div class="col-xs-12 col-sm-6 col-lg-6 col-md-6">
                        <p><a class="text-left" href="http://privacypolicy.acenura.com">Privacy Policy</a></p>
                    </div>
                </div>
            </div>
     </div>
    
</footer>
    <script src="plugins/masterslider/masterslider.min.js"></script>
    <script src="js/master-slider-home.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.17.0/jquery.validate.min.js"></script>
    <script type="text/javascript">
        $(document).ready(function(){

    $(".filter-button").click(function(){
        var value = $(this).attr('data-filter');
        
        if(value == "all")
        {
            //$('.filter').removeClass('hidden');
            $('.filter').show('1000');
        }
        else
        {
//            $('.filter[filter-item="'+value+'"]').removeClass('hidden');
//            $(".filter").not('.filter[filter-item="'+value+'"]').addClass('hidden');
            $(".filter").not('.'+value).hide('3000');
            $('.filter').filter('.'+value).show('3000');
            
        }
    });
    
    if ($(".filter-button").removeClass("active")) {
        $(this).addClass("active");
        }
        $(this).removeClass("active");

});
 $(".hover").mouseleave(
  function () {
    $(this).removeClass("hover");
  }
);


$(window).scroll(function(){
  var sticky = $('.sticky'),
      scroll = $(window).scrollTop();

  if (scroll >= 0) sticky.addClass('fixed');
  else sticky.removeClass('fixed');
});
$('.nav-item a').click(function (e) {
    
    var linkHref = $(this).attr("href");
    var idElement = linkHref.substr(linkHref.indexOf("#"));
    $('html, body').animate({
        scrollTop: $(idElement).offset().top
    }, 1000);
    return false;
});
</script>
<script>
$(document).ready(function () {
    $("#conct").validate({
        rules: {
            "name": {
                required: true,
                
            },
            "email": {
                required: true,
                email: true
            },
            "contact": {
                required: true,
                
            }
        },
        messages: {
            "name": {
                required: "Please, enter a name"
            },
            "email": {
                required: "Please, enter an email",
                email: "Email is invalid"
            },
            "contact": {
                required: "Please, enter a Contact Number"
            }
        },
        submitHandler: function(form) {
            var form_data = new FormData();
            var other_data = $('form#conct').serializeArray();
            $.each(other_data, function(key, input) {
                form_data.append(input.name, input.value);
            });
            $.ajax({
                url: "?page=contactform_ajax",
                type: "POST",
                data: form_data,
                async: false,
                cache: false,
                contentType: false,
                processData: false,
                success: function(data) {
                    var response=data.replace(/\s/g, '');
                    $('#loader').html('');
                    if (response == 'success') {
                        alert("Thank you for Contacting US!Our Contact Team Will Contact you soon!");
                        window.location.href = "?page=home";
                    }
                     else {
                        alert('Try Again Sometime');
                    }
                }
            });
            return false;
        }
    });

});

$(document).ready(function () {
    $("#quoteform").validate({
        rules: {
            "qname": {
                required: true,
                
            },
            "qemail": {
                required: true,
                email: true
            },
            "qphone": {
                required: true,
                
            },
            "qcategory":{
                required:true,
            }
        },
        messages: {
            "qname": {
                required: "Please, enter a name"
            },
            "qemail": {
                required: "Please, enter an email",
                email: "Email is invalid"
            },
            "qphone": {
                required: "Please, enter a Contact Number"
            },
            "qcategory": {
                required: "Please, Select a Categories"
            }
        },
        submitHandler: function(form) {
            var form_data = new FormData();
            var other_data = $('form#quoteform').serializeArray();
            $.each(other_data, function(key, input) {
                form_data.append(input.name, input.value);
            });
            $.ajax({
                url: "?page=contactform_ajax",
                type: "POST",
                data: form_data,
                async: false,
                cache: false,
                contentType: false,
                processData: false,
                success: function(data) {
                    var response=data.replace(/\s/g, '');
                    $('#loader').html('');
                    if (response == 'success') {
                        alert("Thank you for Contacting US!Our Contact Team Will Contact you soon!");
                        window.location.href = "?page=home";
                    }
                     else {
                        alert('Try Again Sometime');
                    }
                }
            });
            return false;
        }
    });

});
</script>
</body>
</html>
        