<?php
date_default_timezone_set('Asia/Kolkata');
require_once('mail/class.phpmailer.php');

$domain='gmail.com';
$password='acee@123';
$company='ACE NURA';
if($_REQUEST['type']=='quote')
{
$name=$_REQUEST['qname'];
$email=$_REQUEST['qemail'];
$phone=$_REQUEST['qphone'];
$category=$_REQUEST['qcategory'];
$message=$_REQUEST['qmessage'];
$sub_m="Requirement Details";

$to_m="sudhakar.acee@gmail.com";
$ton_m="ADMIN";

$body='Dear Admin,<br><br>A New Freebie-Form Enquiry has been Submitted with us.<br><br>Enquiry Details : <br><br>';
$body.='<html><table>';
$body.='<tr><td>Name</td><td>:</td><td>'.$_REQUEST['qname'].'</td></tr>';
$body.='<tr><td>Email</td><td>:</td><td>'.$_REQUEST['qemail'].'</td></tr>';
$body.='<tr><td>Phone</td><td>:</td><td>'.$_REQUEST['qphone'].'</td></tr>';
$body.='<tr><td>Requirement Details</td><td>:</td><td>'.$_REQUEST['qcategory'].'</td></tr>';
$body.='<tr><td>Message</td><td>:</td><td>'.$_REQUEST['qmessage'].'</td></tr>';
$body.='</table></html>';

$checkstatus=$functions->set_query("INSERT INTO `det_require`( `name`, `email`, `contact`, `category`, `message`, `Reg_date`) VALUES ('".$name."','".$email."','".$phone."','".$category."','".$message."','".time()."')");
}

elseif($_REQUEST['type']=='cont'){

	$name=$_REQUEST['name'];
	$email=$_REQUEST['email'];
	$phone=$_REQUEST['contact'];
	$look=$_REQUEST['look'];
	$message=$_REQUEST['message'];
	$sub_m="Contact Details";

	$to_m="sudhakar.acee@gmail.com";
	$ton_m="ADMIN";	

	$body='Dear Admin,<br><br>A New Freebie-Form Enquiry has been Submitted with us.<br><br>Enquiry Details : <br><br>';
	$body.='<html><table>';
	$body.='<tr><td>Name</td><td>:</td><td>'.$_REQUEST['name'].'</td></tr>';
	$body.='<tr><td>Email</td><td>:</td><td>'.$_REQUEST['email'].'</td></tr>';
	$body.='<tr><td>Phone</td><td>:</td><td>'.$_REQUEST['contact'].'</td></tr>';
	$body.='<tr><td>Looking for</td><td>:</td><td>'.$_REQUEST['look'].'</td></tr>';
	$body.='<tr><td>Message</td><td>:</td><td>'.$_REQUEST['message'].'</td></tr>';
	$body.='</table></html>';

	$checkstatus=$functions->set_query("INSERT INTO `getintouch`( `name`, `email`, `contact`, `looking_for`, `message`, `Reg_date`) VALUES ('".$name."','".$email."','".$phone."','".$look."','".$message."','".time()."')");
}




$mail             = new PHPMailer();
//$body             = preg_replace("[\]",'',$body);
$mail->IsSMTP(); 
$mail->SMTPDebug  = 1;            // 1 = errors and messages ,2 = messages only
$mail->SMTPAuth   = true;                 
$mail->SMTPSecure = "ssl";                 
$mail->Host       = "smtp.gmail.com"; 
$mail->Port       = 465;                  
$mail->Username   = "dinesh.acee@".$domain;   
$mail->Password   = $password;            
$mail->SetFrom("dinesh.acee@{$domain}",$company);
$mail->AddReplyTo("dinesh.acee@{$domain}",$company);
$mail->Subject    = $sub_m;
$mail->AltBody    = "To view the message, please use an HTML compatible email viewer!";
$mail->MsgHTML($body);
$address = $to_m;
$mail->AddAddress($address, $ton_m);

/*if($file!=0){
	foreach($file as $filename=>$filet){
$mail->AddAttachment($filet, $filename);
}}
*/
if(!$mail->Send()) { echo "Mailer Error: " . $mail->ErrorInfo;} else {
echo "success";
}
?>