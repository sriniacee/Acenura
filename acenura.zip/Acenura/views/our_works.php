<?php 



if(isset($_REQUEST['id']))

{

    $id=$_REQUEST['id'];

    $workdet=$functions->get_row("SELECT * FROM `ourworks` WHERE  visible=1 AND is_deleted=0 AND id=$id");

}



?>

<section id="servicebanner">

    <div class="container-fluid">

        <div class="container my-auto">

            <h2 class="text-left my-auto">OUR WORKS</h2>

        </div>

        

    </div>

</section>

<section id="service1">

    <div class="container">

        <div class="row">

            <div class="col-12 col-sm-12 col-md-6 col-lg-6">

                <h4>PROJECT NAME:<span style="color: #2d8e5d;text-transform: uppercase;"><?php echo $workdet->project_name; ?></span></h4>

                <p>Visit Site:<a href="<?php echo $workdet->site_url; ?>"><?php echo $workdet->site_url; ?></a></p>

                <h4>DOWNLOAD THE APP</h4>
                <a href="<?php echo $workdet->playstore_url; ?>"><img src="img/app.png"></a>
                <a href="<?php echo $workdet->ios_url; ?>"><img src="img/iphone.png"></a>

            </div>

            <div class="col-12 col-sm-12 col-md-6 col-lg-6">

                <img src="admin/views/ourworks/<?php echo $workdet->image; ?>" alt="<?php echo $workdet->project_name; ?>" style="width:500px;height:300px;">

            </div>

        </div>

    </div>

</section>

<section id="service2">

    <div class="container">

        <div class="row">

            <div class="col-12 col-sm-12 col-md-12 col-lg-12">

                <h2>ABOUT PROJECT</h2>

                <p><?php echo $workdet->about_project; ?></p>

            </div>

        </div>

    </div>

</section>

<section id="service3">

    <div class="container-fluid">

        <div class="row">

            <div class="col-12 col-sm-12 col-md-8 col-lg-8">

                <div class="role">

               <h2>ROLES</h2>

                <p><?php echo $workdet->role; ?></p>

                </div>

             </div>

            <div class="col-12 col-sm-12 col-md-4 col-lg-4">

                <div class="role2">

                <h2>DELIVERABLES</h2>

                <?php

                $getexp=explode(",",$workdet->deliverables);

                foreach ($getexp as $expdet) {

                    echo '<p>'.$expdet.'</p>';

                   

                }

                ?>

              

            </div>

            </div>

        </div>

    </div>

</section>

<section id="service4">

    <div class="container">

        <h2>TESTIMONIALS</h2>

        <blockquote class="blockquote"><p><?php echo $workdet->testimonials; ?></p></blockquote>

    </div>

</section>

<section id="whatwedo">

    <div class="container wedo">

            <h2 class="text-center"><strong>WHAT WE DO</strong></h2>

        <div class="row">

            <div class="col-sm-12 col-md-4 col-lg-4 col-xl-4">

                <div class="card cardwe">

                    <img class="cardwe-img-top" src="img/DesignStatt.png" alt="Cardwe image cap">

                    <div class="cardwe-block">

                        <h3 class="cardwe-title text-center">DESIGN</h3>

                        <p class="cardwe-text text-center">We give your over-all design a plan of action to achieve excellence.</p>

                    </div>

                </div>              

            </div>

            <div class="col-sm-12 col-md-4 col-lg-4 col-xl-4">

                <div class="card cardwe">

                    <img class="cardwe-img-top" src="img/DesignStatt.png" alt="Cardwe image cap">

                    <div class="cardwe-block">

                        <h3 class="cardwe-title text-center">DEVELOPMENT</h3>

                        <p class="cardwe-text text-center">We give your over-all design a plan of action to achieve excellence.</p>

                    </div>

                </div>

            </div>

            <div class="col-sm-12 col-md-4 col-lg-4 col-xl-4">

                <div class="card cardwe">

                    <img class="cardwe-img-top" src="img/DesignStatt.png" alt="Cardwe image cap">

                    <div class="cardwe-block">

                        <h3 class="cardwe-title text-center">DIGITAL MARKETTING</h3>

                        <p class="cardwe-text text-center">We give your over-all design a plan of action to achieve excellence.</p>

                    </div>

                </div>

            </div>

        </div>

    </div>

</section>

<section id="service5">

    <div class="container">

        <div class="row">

            <div class="col-sm-12 col-md-12 col-lg-8 col-xl-8 mx-auto">

                <h4 class="text-center">There's nothing better than a place Where imagination is turned into reality.</h4>

                

            </div>

            <div class="col-sm-12 col-md-12 col-lg-2 col-xl-2 my-auto">

                <p class="text-center"><a href="?page=home#getin" class="btn btn-outline-primary mx-auto ">CONTACT US</a></p>

            </div>

        </div>

    </div>

</section>

