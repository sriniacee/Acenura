

<section class="overflow-hiden">

    <!-- MasterSlider -->

    <div id="P_masterslider" class="master-slider-parent fs-slider ms-parent-id-39">

        <!-- MasterSlider Main -->

        <div id="masterslider" class="master-slider ms-skin-default">

            <div class="ms-overlay-layers">

                <img class="ms-layer msp-cn-121-23" src="plugins/masterslider/images/blank.gif" data-src="plugins/masterslider/images/mouse-scroll-b-icon.png" alt="" style="" data-duration="512" data-ease="easeOutQuint" data-type="image" data-action="scrollToEnd" data-offset-x="0" data-offset-y="20" data-origin="bc" data-position="normal" />

                <img class="ms-layer ms-wheel-icon msp-cn-121-17" src="plugins/masterslider/images/blank.gif" data-src="plugins/masterslider/images/mouse-scroll-w-icon.png" alt="" style="" data-duration="512" data-ease="easeOutQuint" data-type="image" data-action="scrollToEnd" data-offset-x="0" data-offset-y="20" data-origin="bc" data-position="normal" />

            </div>

            <div class="ms-slide fullwidth-layers" data-delay="7.5" data-fill-mode="fill">

                <img src="plugins/masterslider/images/blank.gif" alt="" title="" data-src="plugins/masterslider/images/mscrtvi-background-slide-4.jpg" />

                <img class="ms-layer msp-cn-121-3" src="plugins/masterslider/images/blank.gif" data-src="plugins/masterslider/images/Moblie_phone.png" alt="" style="" data-effect="t(false,35,550,n,15,n,n,n,n,n,n,n,n,n,n)" data-duration="4000" data-delay="1625" data-ease="easeInOutQuart" data-parallax="3" data-type="image" data-offset-x="461" data-offset-y="-11" data-origin="bc" data-position="normal" />

                <img class="ms-layer msp-cn-121-4" src="plugins/masterslider/images/blank.gif" data-src="plugins/masterslider/images/mscrtvi-book-slide-4.png" alt="" style="" data-effect="t(true,n,-250,n,-50,n,n,n,n,n,n,n,n,n,n)" data-duration="4000" data-delay="600" data-ease="easeOutQuart" data-parallax="2" data-type="image" data-offset-x="109" data-offset-y="-315" data-origin="mc" data-position="normal" />

                <!--<img class="ms-layer msp-cn-121-5" src="plugins/masterslider/images/blank.gif" data-src="plugins/masterslider/images/mscrtvi-watch-slide-4.png" alt="" style="" data-effect="t(true,-150,n,n,3,n,n,n,n,n,n,n,n,n,n)" data-duration="5000" data-delay="200" data-ease="easeOutQuart" data-parallax="1" data-type="image" data-offset-x="-21" data-offset-y="112" data-origin="tl" data-position="normal" />-->

                <img class="ms-layer msp-cn-121-2" src="plugins/masterslider/images/blank.gif" data-src="plugins/masterslider/images/mscrtvi-handonkeyboard-slide-4.png" alt="" style="" data-effect="t(true,-30,10,n,n,n,n,n,n,n,n,n,n,n,n)" data-duration="5000" data-delay="1800" data-ease="easeOutQuart" data-parallax="1" data-type="image" data-offset-x="-69" data-offset-y="-30" data-origin="bl" data-position="normal" />

                <div class="ms-layer font-title-55 msp-cn-121-16" style="" data-effect="t(true,n,-30,n,-25,n,n,n,2,2,n,n,n,n,n)" data-duration="2500" data-delay="1000" data-ease="easeOutQuint" data-parallax="3" data-offset-x="0" data-offset-y="2" data-origin="mc" data-position="normal">EATRACKY</div>

                <div class="ms-layer font-desc-24 msp-cn-121-18" style="" data-effect="t(true,n,30,n,-15,n,n,n,2,2,n,n,n,n,n)" data-duration="2500" data-delay="1400" data-ease="easeOutQuint" data-parallax="2" data-offset-x="0" data-offset-y="59" data-origin="mc" data-position="normal">EASY TO RECORD AND INCREASES THE ONTIME PRODUCTIVITY USING EATRACKY</div>

                <a href="http://eatracky.com/" target="_self" class="ms-layer msp-cn-121-21 ms-btn ms-btn-circle ms-btn-n msp-preset-btn-172" data-delay="3000" data-ease="easeOutQuint" data-parallax="1" data-type="button" data-offset-x="0" data-offset-y="115" data-origin="mc" data-position="normal">Read More</a>

            </div>

            <div class="ms-slide" data-delay="7.5" data-fill-mode="fill">

                <img src="plugins/masterslider/images/blank.gif" alt="" title="" data-src="plugins/masterslider/images/mscrtvi-background-slide-1.jpg" />

                <div class="ms-layer msp-cn-121-7" style="" data-effect="t(true,n,n,n,-40,n,n,n,n,n,n,n,-20,n,n)" data-duration="3000" data-delay="200" data-ease="easeOutQuint" data-hide-effect="t(true,n,-100,n,n,n,n,n,n,n,n,n,n,n,n)" data-hide-duration="1500" data-hide-ease="easeInQuint" data-hide-time="5100" data-offset-x="0" data-offset-y="-140" data-origin="mc" data-position="normal">Creativity</div>

                <div class="ms-layer msp-cn-121-6" style="" data-effect="t(true,n,n,n,-40,n,n,n,n,n,n,n,110,n,n)" data-duration="3000" data-delay="400" data-ease="easeOutQuint" data-hide-effect="t(true,n,-100,n,n,n,n,n,n,n,n,n,n,n,n)" data-hide-duration="1500" data-hide-ease="easeInQuint" data-hide-time="5450" data-offset-x="0" data-offset-y="-69" data-origin="mc" data-position="normal">is intelligence having fun.</div>

                <a href="#" target="_self" class="ms-layer ms-btn ms-btn-circle ms-btn-n msp-preset-btn-132" data-duration="1812" data-delay="2162" data-ease="easeOutQuint" data-hide-effect="fade" data-hide-duration="1675" data-hide-ease="easeOutQuint" data-hide-time="6136" data-type="button" data-offset-x="0" data-offset-y="-6" data-origin="mc" data-position="normal">read more</a>

            </div>

            <div class="ms-slide" data-delay="8.2" data-fill-mode="fill">

                <img src="plugins/masterslider/images/blank.gif" alt="" title="" data-src="plugins/masterslider/images/mscrtvi-background-slide-2.jpg" />

                <div class="ms-layer msp-cn-121-11" style="" data-effect="t(true,n,n,n,80,n,n,n,n,n,n,n,-75,n,n)" data-duration="3000" data-delay="400" data-ease="easeOutQuint" data-hide-effect="t(true,n,n,n,8,n,n,n,n,n,n,n,150,n,n)" data-hide-duration="1500" data-hide-ease="easeInQuint" data-hide-time="5900" data-offset-x="264" data-offset-y="181" data-origin="tc" data-position="normal">The most clean & beautiful Minimal</div>

                <div class="ms-layer msp-cn-121-8 text-right" style="" data-effect="t(true,n,n,n,80,n,n,n,n,n,n,n,-70,n,n)" data-duration="3000" data-delay="800" data-ease="easeOutQuint" data-hide-effect="t(true,n,n,n,10,n,n,n,n,n,n,n,150,n,n)" data-hide-duration="1650" data-hide-ease="easeInQuint" data-hide-time="6062" data-offset-x="214" data-offset-y="220" data-origin="tc" data-position="normal">Elegant Template.</div>

            </div>

            <div class="ms-slide" data-delay="7" data-fill-mode="fill">

                <img src="plugins/masterslider/images/blank.gif" alt="" title="" data-src="plugins/masterslider/images/mscrtvi-background-slide-3.jpg" />

                <div class="ms-layer msp-cn-121-14" style="" data-effect="t(true,n,n,n,-60,n,n,n,n,n,n,n,150,n,n)" data-duration="3000" data-delay="200" data-ease="easeOutQuint" data-hide-effect="t(true,n,n,n,40,n,n,n,n,n,n,n,150,n,n)" data-hide-duration="1500" data-hide-ease="easeInQuint" data-hide-time="5225" data-offset-x="156" data-offset-y="239" data-origin="br" data-position="normal">Imagination</div>

                <div class="ms-layer msp-cn-121-12" style="" data-effect="t(true,n,n,n,-60,n,n,n,n,n,n,n,120,n,n)" data-duration="3000" data-delay="600" data-ease="easeOutQuint" data-hide-effect="t(true,n,n,n,30,n,n,n,n,n,n,n,120,n,n)" data-hide-duration="1500" data-hide-ease="easeInQuint" data-hide-time="5337" data-offset-x="156" data-offset-y="210" data-origin="br" data-position="normal">is everything, It is the preview of life's coming attractions.</div>

            </div>

        </div>

        <!-- END MasterSlider Main -->

    </div>

    <!-- END MasterSlider -->

</section>



<section id="expert">

    <div class="container">

        <h2 class="text-center caption"><span style="color: #2d8e5d;font-size: 3rem;">ACE</span><span style="color: #9c302f;font-size: 3rem;">NURA</span> THINK THROUGH INNOVATION, INDIVIDUALITY AND EFFICIENCY.</h2>

        <div class="row">

            <div class="col-sm-12 col-md-12 col-lg-12 col-xl-12 expert-cont">

                <h3 class="text-center">TOGETHER, LET’S THINK FORWARD.</h3>

                <p class="text-center">We understand how important it is to move forward. We believe in progress, so we’re here to help you reach the goals of success and excellence. Your business matters and we want to help guide you into showcasing your services and talents in a more exemplary manner.</p>

                <div class="row innovation">

                                        

                    <div class="col-sm-12 col-md-12 col-lg-3 col-xl-3">

                        <div class="card card-border">

                            <img class="card-img-top" src="img/Innovation.png" alt="Card image cap">

                            <div class="card-block">

                                <h4 class="card-title text-center">INNOVATION</h4>

                                <p class="card-text text-center">We translate your ideas into better service and value.</p>

                            </div>

                        </div>

                    </div>

                    <div class="col-sm-12 col-md-12 col-lg-3 col-xl-3">

                        <div class="card card-border">

                            <img class="card-img-top" src="img/DesignStatt.png" alt="Card image cap">

                            <div class="card-block">

                                <h4 class="card-title text-center">DESIGN STRATEGY</h4>

                                <p class="card-text text-center">We give your over-all design a plan of action to achieve excellence.</p>

                            </div>

                        </div>                      

                    </div>

                    <div class="col-sm-12 col-md-12 col-lg-3 col-xl-3">

                        <div class="card card-border">

                            <img class="card-img-top" src="img/UserExp.png" alt="Card image cap">

                            <div class="card-block">

                                <h4 class="card-title text-center">SOLID USER EXPERIENCE</h4>

                                <p class="card-text text-center">We bring good experience to all your customers and audience.</p>

                            </div>

                        </div>                      

                    </div>

                    <div class="col-sm-12 col-md-12 col-lg-3 col-xl-3">

                        <div class="card card-border">

                            <img class="card-img-top" src="img/CreateSol.png" alt="Card image cap">

                            <div class="card-block">

                                <h4 class="card-title text-center">CREATIVE SOLUTIONS</h4>

                                <p class="card-text text-center">We find the method of bringing out the visualization you want to see.</p>

                            </div>

                        </div>                      

                    </div>

                

            </div>

            </div>

        </div>

    </div>  

</section>

<section id="about">

    <div class="container-fluid abt">

        <div class="row">

                <div class="col-sm-12 col-md-6 col-lg-6 col-xl-6 abt-tiltle my-auto">

                    <h2 class="text-center mx-auto">ABOUT US</h2>

                </div>

                <div class="col-sm-12 col-md-6 col-lg-6 col-xl-6 abt-content">

                    <div class="abt-c">

                    <h4><strong>WE ARE ACE NURA</strong></h4>

                    <p>For the past 5 years, we have been improving our strategies to give our clients a better user experience on digital platforms. The importance of your design coincides with success in your business. So, we want our clients to focus more on their business and worry less about the technology behind it.</p>

                    <a href="#" class="btn btn-outline-primary">VIEW OUR PROJECTS</a>

                   </div>

                </div>

        </div>

    </div>

</section>



<section id="whatwedo">

    <div class="container wedo">

            <h2 class="text-center"><strong>WHAT WE DO</strong></h2>

        <div class="row">

            <div class="col-sm-12 col-md-4 col-lg-4 col-xl-4">

                <div class="card cardwe">

                    <img class="cardwe-img-top" src="img/icon1.png" alt="Cardwe image cap">

                    <div class="cardwe-block">

                        <h3 class="cardwe-title text-center">DESIGN</h3>

                        <p class="cardwe-text text-center">We give your over-all design a plan of action to achieve excellence.</p>

                    </div>

                </div>              

            </div>

            <div class="col-sm-12 col-md-4 col-lg-4 col-xl-4">

                <div class="card cardwe">

                    <img class="cardwe-img-top" src="img/icon2.png" alt="Cardwe image cap">

                    <div class="cardwe-block">

                        <h3 class="cardwe-title text-center">DEVELOPMENT</h3>

                        <p class="cardwe-text text-center">We give your over-all design a plan of action to achieve excellence.</p>

                    </div>

                </div>

            </div>

            <div class="col-sm-12 col-md-4 col-lg-4 col-xl-4">

                <div class="card cardwe">

                    <img class="cardwe-img-top" src="img/icon3.png" alt="Cardwe image cap">

                    <div class="cardwe-block">

                        <h3 class="cardwe-title text-center">DIGITAL MARKETTING</h3>

                        <p class="cardwe-text text-center">We give your over-all design a plan of action to achieve excellence.</p>

                    </div>

                </div>

            </div>

        </div>

    </div>

</section>



<section id="works">

    <div class="container">

            <h2 class="text-center">OUR WORKS</h2>

       <div align="center">

            <button class="btn btn-outline-primary filter-button" data-filter="all">All</button>

            <button class="btn btn-outline-primary filter-button" data-filter="application">APPLICATION</button>

            <button class="btn btn-outline-primary filter-button" data-filter="web">WEB</button>

            <button class="btn btn-outline-primary filter-button" data-filter="mobile">MOBILE</button>

        </div>

        <div class="row">

        <?php

          $ourworks=$functions->get_result("SELECT * FROM `ourworks` WHERE  visible=1 AND is_deleted=0 ORDER by id DESC LIMIT 12");

            foreach($ourworks as $nework)

            {



                echo '<div class="gallery_product col-lg-3 col-md-4 col-sm-6 col-12 filter '.$nework->platform.'">

                        <figure class="snip1548"><img src="admin/views/ourworks/'.$nework->image.'" alt="'.$nework->project_name.'"/>

                          <figcaption>

                            <h3>'.$nework->project_name.'</h3>

                            <h5>View</h5>

                          </figcaption><a href="?page=our_works&id='.$nework->id.'"></a>

                        </figure>

                     </div>';

            }

         ?>

           </div>

</div>

</section>

<section id="packages">

    <div class="container">

            <h2 class="text-center"><strong>PRICE PACKAGE</strong></h2>

            <p class="text-center">We are offering these following ready made and custom web design packages which can be helpful for your quick and small needs. Sites such as landing pages, microsites, short campaign needs, quick shopping cart and many other smaller needs. Write to us to learn more about our packages.</p>



       <div class="row">

        <div class="col-12 col-sm-6 col-md-6 col-lg-3">

            <!-- PRICE ITEM -->

            <div class="panel price panel-blue">

                <div class="panel-heading  text-center">

                    <h3>MICROSITE</h3>

                </div>

                <div class="panel-body text-center">

                    <p class="lead" style="font-size:40px"><strong>$399+</strong></p>

                </div>

                <ul class="list-group list-group-flush text-center">

                    <li class="list-group-item"><i class="icon-ok text-danger"></i>5 page Website</li>

                    <li class="list-group-item"><i class="icon-ok text-danger"></i>Animated Banner</li>

                    <li class="list-group-item"><i class="icon-ok text-danger"></i>News Letter</li>

                    <li class="list-group-item"><i class="icon-ok text-danger"></i>1 Contact Form</li>

                    <li class="list-group-item"><i class="icon-ok text-danger"></i>Picture Gallery</li>

                    <li class="list-group-item"><i class="icon-ok text-danger"></i>Responsive Design</li>

                </ul>

                <div class="panel-footer">

                    <a class="btn btn-lg btn-block pbtn" href="#" data-toggle="modal" data-target="#exampleModal">GET A QUOTE</a>

                </div>

            </div>

            <!-- /PRICE ITEM -->

        </div>

        <div class="col-12 col-sm-6 col-md-6 col-lg-3">

            <!-- PRICE ITEM -->

            <div class="panel price panel-blue">

                <div class="panel-heading arrow_box text-center">

                    <h3>SMALL BUSINESS</h3>

                </div>

                <div class="panel-body text-center">

                    <p class="lead" style="font-size:40px"><strong>$850+</strong></p>

                </div>

                <ul class="list-group list-group-flush text-center">

                    <li class="list-group-item"><i class="icon-ok text-info"></i>Custom Design</li>

                    <li class="list-group-item"><i class="icon-ok text-info"></i>15 Pages Website</li>

                    <li class="list-group-item"><i class="icon-ok text-info"></i>Responsive Design</li>

                    <li class="list-group-item"><i class="icon-ok text-info"></i>Contact Forms</li>

                    <li class="list-group-item"><i class="icon-ok text-info"></i>SEO Optimized</li>

                    <li class="list-group-item"><i class="icon-ok text-info"></i>CMS</li>

                    <li class="list-group-item"><i class="icon-ok text-info"></i>News Letter</li>

                    <li class="list-group-item"><i class="icon-ok text-info"></i>Video Gallery</li>

                    <li class="list-group-item"><i class="icon-ok text-info"></i>Free Domain Name</li>

                    <li class="list-group-item"><i class="icon-ok text-info"></i>Search Engine Submission</li>

                </ul>

                <div class="panel-footer">

                    <a class="btn btn-lg btn-block pbtn" href="#" data-toggle="modal" data-target="#exampleModal">GET A QUOTE</a>

                </div>

            </div>

            <!-- /PRICE ITEM -->

        </div>

        <div class="col-12 col-sm-6 col-md-6 col-lg-3">

            <!-- PRICE ITEM -->

            <div class="panel price panel-blue">

                <div class="panel-heading arrow_box text-center">

                    <h3>MEDIUM BUSINESS</h3>

                </div>

                <div class="panel-body text-center">

                    <p class="lead" style="font-size:40px"><strong>$1600+</strong></p>

                </div>

                <ul class="list-group list-group-flush text-center">

                    <li class="list-group-item"><i class="icon-ok text-success"></i>Content Management Website</li>

                    <li class="list-group-item"><i class="icon-ok text-success"></i>Video Gallery (Optional)</li>

                    <li class="list-group-item"><i class="icon-ok text-success"></i>Testimonials, Contact Form</li>

                    <li class="list-group-item"><i class="icon-ok text-success"></i>Responsive Design</li>

                    <li class="list-group-item"><i class="icon-ok text-success"></i>Seo Optimized</li>

                    <li class="list-group-item"><i class="icon-ok text-success"></i>Search Engine Submission</li>

                    <li class="list-group-item"><i class="icon-ok text-success"></i>Categories</li>

                    <li class="list-group-item"><i class="icon-ok text-success"></i>Product</li>

                    <li class="list-group-item"><i class="icon-ok text-success"></i>Customized CMS(Dynamic Backend)</li>

                </ul>

                <div class="panel-footer">

                    <a class="btn btn-lg btn-block pbtn" href="#" >GET A QUOTE</a>

                </div>

            </div>

            <!-- /PRICE ITEM -->

        </div>

        <div class="col-12 col-sm-6 col-md-6 col-lg-3">

            <!-- PRICE ITEM -->

            <div class="panel price panel-blue">

                <div class="panel-heading arrow_box text-center">

                    <h3>e-COMMERCE SITE</h3>

                </div>

                <div class="panel-body text-center">

                    <p class="lead" style="font-size:40px"><strong>$2000+</strong></p>

                </div>

                <ul class="list-group list-group-flush text-center">

                    <li class="list-group-item"><i class="icon-ok text-success"></i>Responsive Design</li>

                    <li class="list-group-item"><i class="icon-ok text-success"></i>Seo Optimized</li>

                    <li class="list-group-item"><i class="icon-ok text-success"></i>Online Builder</li>

                    <li class="list-group-item"><i class="icon-ok text-success"></i>WooCommerce Powered</li>

                    <li class="list-group-item"><i class="icon-ok text-success"></i>Custom Design</li>

                    <li class="list-group-item"><i class="icon-ok text-success"></i>Setup &amp; Config</li>

                    <li class="list-group-item"><i class="icon-ok text-success"></i>cPanel Included</li>

                    <li class="list-group-item"><i class="icon-ok text-success"></i>unlimited email accounts</li>

                    <li class="list-group-item"><i class="icon-ok text-success"></i>Payment Module via 2checkout / Paypal</li>

                    <li class="list-group-item"><i class="icon-ok text-success"></i>Search Engine Submission</li>

                </ul>

                <div class="panel-footer">

                    <a class="btn btn-lg btn-block pbtn" href="#" data-toggle="modal" data-target="#exampleModal">GET A QUOTE</a>

                </div>

            </div>

            <!-- /PRICE ITEM -->

        </div>

    </div>

         <p class="text-center price-bot">If you have any questions or you need something more specific, don’t hesitate to ask us for some help!</p>

         <a href="#" class="text-center btn btn-lg btn-block pricbtn" data-toggle="modal" data-target="#exampleModal">REQUEST A QUOTE</a>

    

    </div>  

</section>



<section id="getin">

    <div class="container get-touch">

            <h2 class="text-center"><strong>GET IN TOUCH</strong></h2>

            <h5 class="text-center">LET’S START COLLABORATING</h5>

            <p class="text-center">There’s nothing better than a place where imagination is turned into reality. If you’re in need of more information, please don’t hesitate to contact us.</p>        

            <form id="conct" method="post">

                <input type="hidden" name="type" value="cont">

              <div class="form-row">

                <div class="form-group col-md-6">

                  <input type="text" class="form-control" id="name" name="name" placeholder="Name">

                </div>

                <div class="form-group col-md-6">

                  <input type="text" class="form-control" id="email" name="email" placeholder="Email">

                </div>

              </div>

              <div class="form-row">

                <div class="form-group col-md-6">

                  <input type="text" class="form-control" id="contact_nuber" name="contact" placeholder="Contact Number">

                </div>

                <div class="form-group col-md-6">

                  <input type="text" class="form-control" id="look" name="look" placeholder="Looking For">

                </div>

              </div>

              <div class="form-row">

                <div class="form-group col-md-12">

                   <textarea class="form-control" id="message" placeholder="Message" name="message" rows="4"></textarea>

                </div>

              </div>              

              <button type="submit" class="btn btn-block getbtn"><i class="fa fa-paper-plane" aria-hidden="true"></i>SEND</button>

            </form>



    </div>

</section>



<section id="contact">

    <div class="container">

        <h2 class="text-center">CONTACT US</h2>

        <div class="row">

        <div class="col-xs-12 col-sm-12 col-lg-6 col-md-6">

           <div class="text-center c1">

            <h4>CORPORATE OFFICE</h4>

            <address>

            <table style="border: none;">

                <tr><td><i class="fa fa-whatsapp" aria-hidden="true"></i></td><td>+(65)-6694.3351</td></tr>

                <tr><td><i class="fa fa-envelope-o" aria-hidden="true"></i></td><td>solutions@acenura.com</td></tr>

                <tr><td></td><td>Blk 668, #02-08, Chander road,</td></tr>

                <tr><td></td><td>Singapore - 210668.</td></tr>

            </table>

            </address>

        </div>

        </div>

        <div class="col-xs-12 col-sm-12 col-lg-6 col-md-6 my-auto">

            <div class="text-center c2">

            <h4>DEVELOPMENT CENTER</h4>

            <address>

            <table style="border: none;">

                <tr><td><i class="fa fa-whatsapp" aria-hidden="true"></i></td><td>+(65)-6694.3351</td></tr>

                <tr><td><i class="fa fa-envelope-o" aria-hidden="true"></i></td><td>solutions@acenura.com</td></tr>

                <tr><td></td><td>49,NerkundramPathai,LIC Colony,</td></tr>

                <tr><td></td><td>Vadapalani,Chennai,</td></tr>

                <tr><td></td><td>Tamil Nadu 600026.</td></tr>

            </table>

            </address>

        </div>

        </div>

    </div>

</div>

</section>



<!-- Modal -->

<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">

  <div class="modal-dialog" role="document">

    <div class="modal-content">

      <div class="modal-header">

        <a class="modal-title text-center" id="exampleModalLabel"><img src="img/logo.png" style="width: 125px;"></a>

        <button type="button" class="close" data-dismiss="modal" aria-label="Close">

          <span aria-hidden="true">&times;</span>

        </button>

      </div>

      <form id="quoteform" method="post">

        <input type="hidden" name="type" value="quote">

      <div class="modal-body">

        

      <div class="form-group col-md-12">

          <input type="text" class="form-control" id="name" name="qname" placeholder="Name">

      </div>

       <div class="form-group col-md-12">

          <input type="text" class="form-control" id="email" name="qemail" placeholder="Email">

      </div>

       <div class="form-group col-md-12">

          <input type="text" class="form-control" id="phone" name="qphone" placeholder="Phone Number">

      </div>

        <div class="form-group col-md-12">

         <select class="form-control" name="qcategory" >

            <option value="" selected="selected">-Select- </option>

            <option value="Web Design">Web Design</option>

            <option value="eCommerce Store">eCommerce </option>

            <option value="WordPress Web Design">WordPress Web Design</option>

            <option value="Magento Web Design">Magento Web Design</option>

            <option value="SEO - Search Engine Optimization">SEO - Search Engine Optimization</option>

        </select>

      </div>

       <div class="form-group col-md-12">

           <textarea class="form-control" id="message" placeholder="Detailed Requirement" name="qmessage" rows="4"></textarea>

      </div>



      </div>



      <div class="modal-footer">

        <button type="Submit" class="btn btn-outline-primary">Send Message</button>

        <button type="button" class="btn btn-outline-primary" data-dismiss="modal">Close</button>    

      </div>

    </div>

    </form>

  </div>

</div>



<!-- Modal Ends -->

