<!DOCTYPE html>
<html>
<head>
    <title>AceNura</title>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
    <link href="plugins/masterslider/style/masterslider.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <link href="https://fonts.googleapis.com/css?family=Roboto:100,300,400,500,700,900" rel="stylesheet">

    <script type="text/javascript" src="http://code.jquery.com/jquery-latest.min.js"></script>
    <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.6/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/js/bootstrap.min.js"></script>
</head>
<body>
    <!-- Header Starts -->
    <header>
        <div class="container-fluid sticky">
            <div class="row">
                <div class="col-sm-12 col-md-12 col-lg-9 col-xl-9">
                    <nav class="navbar navbar-expand-sm navbar-light bg-faded">
                        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#nav-content" aria-controls="nav-content" aria-expanded="false" aria-label="Toggle navigation">
                            <span class="navbar-toggler-icon"></span>
                        </button>

                        <!-- Brand -->
                        <a class="navbar-brand" href="index.php"><img src="img/logo.png" class="img-fluid" alt="logo"></a>

                        <!-- Links -->
                        <div class="collapse navbar-collapse justify-content-end" id="nav-content">
                            <ul class="navbar-nav">
                                <li class="nav-item">
                                    <a class="nav-link" href="index.php">HOME</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="#about">ABOUT US</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="#whatwedo">SERVICES</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="#works">WORK</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="#packages">PACKAGES</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="#contact">CONTACT</a>
                                </li>
                            </ul>
                    </nav>
                    </div>
                    <div class="col-sm-12 col-md-12 col-lg-3 col-xl-3 ">
                        <div class="text-center center-block" id="searc">
                            <a href="#" class="social fa fa-facebook"></a>
                            <a href="#" class="social fa fa-linkedin"></a>
                            <a href="#" class="social fa fa-google"></a>
                            <input type="search" placeholder="Search">
                        </div>

                    </div>
                </div>
            </div>
    </header>
<!-- Header Ends -->