<?php
/**
* Author : Dinesh G ,Web Developer - Acenura
* Initializing Project Environment
*/
@ob_start();
@session_start();	

define('MODE', 'local'); // local - local connections (or) server - server connections

define('ENVIRONMENT', 'development');

if (defined('ENVIRONMENT'))
{
	switch (ENVIRONMENT)
	{
		case 'development':
			error_reporting(E_ERROR | E_WARNING | E_PARSE | E_NOTICE);
		break;
		case 'production':
			error_reporting(0);
		break;
	}
}

require_once('init.php');

$controllers->$page($site);

?>