<?php
/**
* Author : Dinesh G ,Web Developer - Acenura

*/

/**
* Define Your Pages Here
*/
$total_pages=array('home');

/*
* Load Libararies Here
*/
$libraries=array('core','db','functions','controllers');


/**
* Fetching the current Page
*/
$site['site_url']=$_SERVER['SERVER_NAME'];

(isset($_REQUEST['page'])) ? $site['page'] = $_REQUEST['page'] : $site['page']="home";

foreach ($libraries as $lib) {
	include_once($lib.'.php');
	$site[$lib]=new $lib();
}


foreach($site as $key=>$value)
{
	
	$$key = $value;
}

/**
* 
*/
?>