<?php

Class controllers extends core
{
	public function home($site)
	{
		foreach($site as $key=>$value)
		{
			$$key = $value;
		}
		
		include_once('views/header.php');
		include_once('views/'.$page.'.php');
		include_once('views/footer.php');
	}	
   public function our_works($site)
	{
		foreach($site as $key=>$value)
		{
			$$key = $value;
		}
		
		include_once('views/header.php');
		include_once('views/'.$page.'.php');
		include_once('views/footer.php');
	}
	public function contactform_ajax($site)
	{
		foreach($site as $key=>$value)
		{
			$$key = $value;
		}
		
		include_once('views/'.$page.'.php');

	}
}
?>